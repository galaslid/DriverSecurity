namespace WindowsDriverProtection.Models;

/// <summary>
/// Application configuration class
/// </summary>
public class AppConfig
{
    /// <summary>
    /// Path to the vulnerable drivers database file
    /// </summary>
    public string DatabasePath { get; set; } = "vulnerable_drivers.json";
    
    /// <summary>
    /// Whether to enable notifications
    /// </summary>
    public bool EnableNotifications { get; set; } = true;
    
    /// <summary>
    /// Whether to automatically update the database
    /// </summary>
    public bool AutoUpdateDatabase { get; set; } = true;
    
    /// <summary>
    /// Interval in days between database updates
    /// </summary>
    public int UpdateIntervalDays { get; set; } = 7;
    
    /// <summary>
    /// Date of the last database update
    /// </summary>
    public DateTime LastDatabaseUpdate { get; set; } = DateTime.MinValue;
} 