namespace WindowsDriverProtection.Models;

/// <summary>
/// Класс, представляющий информацию о драйвере
/// </summary>
public class DriverInfo
{
    /// <summary>
    /// Имя драйвера
    /// </summary>
    public string Name { get; set; } = string.Empty;
    
    /// <summary>
    /// Отображаемое имя драйвера
    /// </summary>
    public string DisplayName { get; set; } = string.Empty;
    
    /// <summary>
    /// Путь к файлу драйвера
    /// </summary>
    public string Path { get; set; } = string.Empty;
    
    /// <summary>
    /// Состояние драйвера (Running, Stopped, и т.д.)
    /// </summary>
    public string State { get; set; } = string.Empty;
    
    /// <summary>
    /// Режим запуска драйвера (Boot, System, Automatic, Manual, Disabled)
    /// </summary>
    public string StartMode { get; set; } = string.Empty;
    
    /// <summary>
    /// Хеш драйвера (SHA-256)
    /// </summary>
    public string Hash { get; set; } = string.Empty;
    
    /// <summary>
    /// Подписан ли драйвер
    /// </summary>
    public bool IsSigned { get; set; }
    
    /// <summary>
    /// Является ли драйвер уязвимым
    /// </summary>
    public bool IsVulnerable { get; set; }
    
    /// <summary>
    /// Информация об уязвимости
    /// </summary>
    public string VulnerabilityInfo { get; set; } = string.Empty;
    
    /// <summary>
    /// Категория уязвимости
    /// </summary>
    public string VulnerabilityCategory { get; set; } = string.Empty;
    
    /// <summary>
    /// Возвращает строковое представление информации о драйвере
    /// </summary>
    public override string ToString()
    {
        return $"{Name} ({(IsVulnerable ? "УЯЗВИМЫЙ" : "OK")})";
    }
    
    /// <summary>
    /// Возвращает подробную информацию о драйвере
    /// </summary>
    public string GetDetailedInfo()
    {
        var result = $"Драйвер: {Name}\n" +
                     $"Отображаемое имя: {DisplayName}\n" +
                     $"Путь: {Path}\n" +
                     $"Состояние: {State}\n" +
                     $"Режим запуска: {StartMode}\n" +
                     $"SHA-256: {Hash}\n" +
                     $"Подписан: {(IsSigned ? "Да" : "Нет")}\n" +
                     $"Уязвимый: {(IsVulnerable ? "Да" : "Нет")}";
        
        if (IsVulnerable && !string.IsNullOrEmpty(VulnerabilityInfo))
        {
            result += $"\n\nИнформация об уязвимости:\n" +
                      $"Категория: {VulnerabilityCategory}\n" +
                      $"Описание: {VulnerabilityInfo}";
        }
        
        return result;
    }
} 