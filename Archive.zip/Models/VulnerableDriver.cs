using System.Text.Json.Serialization;

namespace WindowsDriverProtection.Models;

/// <summary>
/// Модель для хранения информации об уязвимом драйвере из базы данных loldrivers.io
/// </summary>
public class VulnerableDriver
{
    /// <summary>
    /// Идентификатор драйвера
    /// </summary>
    [JsonPropertyName("id")]
    public string Id { get; set; } = string.Empty;

    /// <summary>
    /// Теги драйвера (обычно содержит имя файла драйвера)
    /// </summary>
    [JsonPropertyName("tags")]
    public List<string> Tags { get; set; } = new();

    /// <summary>
    /// Статус верификации
    /// </summary>
    [JsonPropertyName("verified")]
    public string Verified { get; set; } = string.Empty;

    /// <summary>
    /// Автор драйвера
    /// </summary>
    [JsonPropertyName("author")]
    public string Author { get; set; } = string.Empty;

    /// <summary>
    /// Дата создания записи
    /// </summary>
    [JsonPropertyName("created")]
    public string Created { get; set; } = string.Empty;

    /// <summary>
    /// Идентификатор MITRE ATT&CK
    /// </summary>
    [JsonPropertyName("mitreId")]
    public string MitreId { get; set; } = string.Empty;

    /// <summary>
    /// Категория уязвимости
    /// </summary>
    [JsonPropertyName("category")]
    public string Category { get; set; } = string.Empty;

    /// <summary>
    /// Команды и описание уязвимости
    /// </summary>
    [JsonPropertyName("commands")]
    public VulnerableDriverCommands Commands { get; set; } = new();

    /// <summary>
    /// Известные уязвимые образцы (хеши)
    /// </summary>
    [JsonPropertyName("knownVulnerableSamples")]
    public object KnownVulnerableSamples { get; set; } = new List<string>();

    /// <summary>
    /// Получает список известных уязвимых образцов
    /// </summary>
    public List<string> GetKnownVulnerableSamples()
    {
        if (KnownVulnerableSamples is List<string> list)
            return list;
        return new List<string>();
    }
}

/// <summary>
/// Модель для хранения информации о командах и описании уязвимости
/// </summary>
public class VulnerableDriverCommands
{
    /// <summary>
    /// Команда для эксплуатации уязвимости
    /// </summary>
    [JsonPropertyName("command")]
    public string Command { get; set; } = string.Empty;

    /// <summary>
    /// Описание уязвимости
    /// </summary>
    [JsonPropertyName("description")]
    public string Description { get; set; } = string.Empty;

    /// <summary>
    /// Операционная система
    /// </summary>
    [JsonPropertyName("operatingSystem")]
    public string OperatingSystem { get; set; } = string.Empty;
} 