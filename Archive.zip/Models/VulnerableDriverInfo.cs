namespace WindowsDriverProtection.Models;

/// <summary>
/// Class representing information about a vulnerable driver
/// </summary>
public class VulnerableDriverInfo
{
    /// <summary>
    /// Driver name
    /// </summary>
    public string Name { get; set; } = string.Empty;
    
    /// <summary>
    /// Driver SHA-256 hash
    /// </summary>
    public string Hash { get; set; } = string.Empty;
    
    /// <summary>
    /// Vulnerability description
    /// </summary>
    public string Description { get; set; } = string.Empty;
    
    /// <summary>
    /// Vulnerability category (e.g., "Memory Manipulation", "Privilege Escalation")
    /// </summary>
    public string Category { get; set; } = string.Empty;
    
    /// <summary>
    /// CVE identifier (if available)
    /// </summary>
    public string CVE { get; set; } = string.Empty;
    
    /// <summary>
    /// Date when the vulnerability was added to the database
    /// </summary>
    public DateTime DateAdded { get; set; } = DateTime.Now;
    
    /// <summary>
    /// Severity level (e.g., "Critical", "High", "Medium", "Low")
    /// </summary>
    public string Severity { get; set; } = "High";
    
    /// <summary>
    /// Additional notes about the vulnerability
    /// </summary>
    public string Notes { get; set; } = string.Empty;
} 