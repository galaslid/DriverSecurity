using WindowsDriverProtection.Services;
using WindowsDriverProtection.UI;
using WindowsDriverProtection.Utils;

namespace WindowsDriverProtection;

/// <summary>
/// Main program class
/// </summary>
public class Program
{
    /// <summary>
    /// Application entry point
    /// </summary>
    /// <param name="args">Command line arguments</param>
    public static async Task Main(string[] args)
    {
        try
        {
            // Initialize services
            var configManager = new ConfigManager();
            var vulnerableDriverDatabase = new VulnerableDriverDatabase(configManager);
            var driverService = new DriverService(configManager, vulnerableDriverDatabase);
            var notificationService = new NotificationService(configManager);
            var menuManager = new MenuManager(driverService, vulnerableDriverDatabase, configManager, notificationService);

            // Check for command line arguments
            if (args.Length > 0)
            {
                await ProcessCommandLineArguments(args, driverService, vulnerableDriverDatabase, configManager, notificationService);
            }
            else
            {
                // Show interactive menu
                menuManager.ShowMainMenu();
            }
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Critical error: {ex.Message}");
            Console.WriteLine(ex.StackTrace);
            Console.ResetColor();
            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }

    /// <summary>
    /// Processes command line arguments
    /// </summary>
    /// <param name="args">Command line arguments</param>
    /// <param name="driverService">Driver service</param>
    /// <param name="vulnerableDriverDatabase">Vulnerable drivers database</param>
    /// <param name="configManager">Configuration manager</param>
    /// <param name="notificationService">Notification service</param>
    private static async Task ProcessCommandLineArguments(
        string[] args,
        DriverService driverService,
        VulnerableDriverDatabase vulnerableDriverDatabase,
        ConfigManager configManager,
        NotificationService notificationService)
    {
        string command = args[0].ToLower();

        switch (command)
        {
            case "scan":
                // Scan system for vulnerable drivers
                ConsoleHelper.WriteInfo("Scanning system for vulnerable drivers...");
                var drivers = driverService.GetInstalledDrivers();
                int vulnerableCount = drivers.Count(d => d.IsVulnerable);
                
                if (vulnerableCount > 0)
                {
                    ConsoleHelper.WriteWarning($"Found {vulnerableCount} vulnerable drivers out of {drivers.Count} total drivers");
                    
                    foreach (var driver in drivers.Where(d => d.IsVulnerable))
                    {
                        ConsoleHelper.WriteError($"Vulnerable driver: {driver.Name}");
                        ConsoleHelper.WriteError($"  Path: {driver.Path}");
                        ConsoleHelper.WriteError($"  Vulnerability: {driver.VulnerabilityInfo}");
                        ConsoleHelper.WriteError($"  Category: {driver.VulnerabilityCategory}");
                        ConsoleHelper.WriteSeparator();
                    }
                }
                else
                {
                    ConsoleHelper.WriteSuccess($"No vulnerable drivers found among {drivers.Count} drivers");
                }
                
                notificationService.NotifyScanComplete(drivers.Count, vulnerableCount);
                break;
                
            case "update":
                // Update vulnerable drivers database
                ConsoleHelper.WriteInfo("Updating vulnerable drivers database...");
                bool success = await vulnerableDriverDatabase.UpdateDatabaseFromOnlineSource();
                
                if (success)
                {
                    ConsoleHelper.WriteSuccess("Database updated successfully");
                    notificationService.NotifyDatabaseUpdate(true, "Database updated successfully");
                }
                else
                {
                    ConsoleHelper.WriteError("Failed to update database");
                    notificationService.NotifyDatabaseUpdate(false, "Failed to update database");
                }
                break;
                
            case "driver":
                // Get information about a specific driver
                if (args.Length < 2)
                {
                    ConsoleHelper.WriteError("Driver name not specified. Usage: driver <driver_name>");
                    return;
                }
                
                string driverName = args[1];
                var driverInfo = driverService.GetDriverInfo(driverName);
                
                if (driverInfo != null)
                {
                    ConsoleHelper.WriteDriverInfo(driverInfo);
                }
                else
                {
                    ConsoleHelper.WriteError($"Driver '{driverName}' not found");
                }
                break;
                
            case "help":
                // Show help information
                ShowHelp();
                break;
                
            default:
                ConsoleHelper.WriteError($"Unknown command: {command}");
                ShowHelp();
                break;
        }
    }

    /// <summary>
    /// Displays help information
    /// </summary>
    private static void ShowHelp()
    {
        ConsoleHelper.WriteHeader("Windows Driver Protection System - Help");
        ConsoleHelper.WriteSeparator();
        
        Console.WriteLine("Available commands:");
        Console.WriteLine("  scan                - Scan system for vulnerable drivers");
        Console.WriteLine("  update              - Update vulnerable drivers database");
        Console.WriteLine("  driver <driver_name> - Get information about a specific driver");
        Console.WriteLine("  help                - Show this help information");
        Console.WriteLine();
        Console.WriteLine("Run without arguments to start in interactive mode.");
        
        ConsoleHelper.WriteSeparator();
    }
} 