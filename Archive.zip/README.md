# Windows Driver Protection System

## Description
Windows Driver Protection System is an application designed to protect Windows systems from BYOVD (Bring Your Own Vulnerable Driver) attacks. The application scans the system for installed drivers, checks them against a database of known vulnerable drivers, and alerts the user if any vulnerable drivers are found.

## Current Capabilities (Phase 1)
- Scanning the system for installed drivers
- Checking drivers against a database of known vulnerable drivers
- Displaying detailed information about drivers (name, path, hash, signature status)
- Managing a local database of vulnerable drivers (add, remove, update)
- Command-line interface for automation
- Interactive menu for ease of use

## Requirements
- Windows 10/11
- .NET 7.0 or higher
- Administrator privileges (required for accessing driver information)

## Installation
1. Download the latest release from the [Releases](https://github.com/yourusername/WindowsDriverProtection/releases) page
2. Extract the archive to a location of your choice
3. Run `WindowsDriverProtection.exe` as administrator

## Usage
The application can be used in two modes:

### Interactive Mode
Run the application without any arguments to enter interactive mode. The main menu provides the following options:
1. Scan system for vulnerable drivers
2. View installed drivers
3. View vulnerable drivers database
4. Add driver to vulnerable database
5. Remove driver from vulnerable database
6. Update vulnerable drivers database
7. Settings
0. Exit

### Command Line Mode
The application supports the following commands:
- `scan` - Scan the system for vulnerable drivers
- `update` - Update the vulnerable drivers database
- `driver <driver_name>` - Get information about a specific driver
- `help` - Show help information

Example:
```
WindowsDriverProtection.exe scan
```

## Recommended Analysis Steps
1. Run a system scan to identify any vulnerable drivers
2. Review the details of any identified vulnerable drivers
3. Consider uninstalling or updating vulnerable drivers
4. Set up regular scans to monitor for new vulnerable drivers

## Planned Features (Phase 2)
- Real-time monitoring of driver loading
- Automatic updates of the vulnerable driver database from online sources
- Integration with Windows Defender Application Control (WDAC) to block vulnerable drivers
- Detailed reporting and export capabilities
- System notifications for critical events

## Author
This project is part of a diploma thesis on Windows driver security and protection against BYOVD attacks.

## License
MIT License 