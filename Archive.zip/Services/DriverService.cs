using System.Management;
using System.Security.Cryptography;
using Microsoft.Win32;
using System.ServiceProcess;
using WindowsDriverProtection.Models;
using WindowsDriverProtection.Utils;

namespace WindowsDriverProtection.Services;

/// <summary>
/// Service for working with Windows drivers
/// </summary>
public class DriverService
{
    private readonly ConfigManager _configManager;
    private readonly VulnerableDriverDatabase _vulnerableDriverDatabase;

    /// <summary>
    /// DriverService constructor
    /// </summary>
    /// <param name="configManager">Configuration manager</param>
    /// <param name="vulnerableDriverDatabase">Vulnerable drivers database</param>
    public DriverService(ConfigManager configManager, VulnerableDriverDatabase vulnerableDriverDatabase)
    {
        _configManager = configManager;
        _vulnerableDriverDatabase = vulnerableDriverDatabase;
    }

    /// <summary>
    /// Gets a list of installed drivers
    /// </summary>
    /// <returns>List of driver information</returns>
    public List<DriverInfo> GetInstalledDrivers()
    {
        List<DriverInfo> drivers = new();
        
        try
        {
            // Get all services of type "Driver"
            var serviceControllers = ServiceController.GetDevices();
            
            foreach (var service in serviceControllers)
            {
                try
                {
                    var driverInfo = new DriverInfo
                    {
                        Name = service.ServiceName,
                        DisplayName = service.DisplayName,
                        State = service.Status.ToString(),
                        StartMode = GetStartMode(service)
                    };
                    
                    // Get driver path
                    driverInfo.Path = GetDriverPath(service.ServiceName);
                    
                    // Calculate hash if path is available
                    if (!string.IsNullOrEmpty(driverInfo.Path) && File.Exists(driverInfo.Path))
                    {
                        driverInfo.Hash = CalculateFileHash(driverInfo.Path);
                        driverInfo.IsSigned = IsDriverSigned(driverInfo.Path);
                        
                        // Check if driver is in the vulnerable database
                        var vulnerableInfo = _vulnerableDriverDatabase.CheckVulnerability(driverInfo.Hash);
                        if (vulnerableInfo != null)
                        {
                            driverInfo.IsVulnerable = true;
                            driverInfo.VulnerabilityInfo = vulnerableInfo.Description;
                            driverInfo.VulnerabilityCategory = vulnerableInfo.Category;
                        }
                    }
                    
                    drivers.Add(driverInfo);
                }
                catch (Exception ex)
                {
                    ConsoleHelper.WriteWarning($"Error processing driver {service.ServiceName}: {ex.Message}");
                }
            }
        }
        catch (Exception ex)
        {
            ConsoleHelper.WriteError($"Error retrieving drivers: {ex.Message}");
        }
        
        return drivers;
    }

    /// <summary>
    /// Gets the start mode of a service
    /// </summary>
    /// <param name="service">Service controller</param>
    /// <returns>Start mode as string</returns>
    private string GetStartMode(ServiceController service)
    {
        try
        {
            // This is a simplified implementation
            // In a real application, you would use WMI or registry to get the start mode
            return "Unknown"; // Placeholder
        }
        catch
        {
            return "Unknown";
        }
    }

    /// <summary>
    /// Gets the file path of a driver
    /// </summary>
    /// <param name="serviceName">Service name</param>
    /// <returns>Driver file path</returns>
    private string GetDriverPath(string serviceName)
    {
        try
        {
            // This is a simplified implementation
            // In a real application, you would use the registry to get the driver path
            string systemRoot = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            string driversPath = Path.Combine(systemRoot, "System32", "drivers");
            
            // Try to find the driver file with .sys extension
            string potentialPath = Path.Combine(driversPath, $"{serviceName}.sys");
            if (File.Exists(potentialPath))
            {
                return potentialPath;
            }
            
            // If not found, try to search in the drivers directory
            var files = Directory.GetFiles(driversPath, "*.sys");
            foreach (var file in files)
            {
                if (Path.GetFileNameWithoutExtension(file).Equals(serviceName, StringComparison.OrdinalIgnoreCase))
                {
                    return file;
                }
            }
            
            return string.Empty;
        }
        catch
        {
            return string.Empty;
        }
    }

    /// <summary>
    /// Calculates SHA-256 hash of a file
    /// </summary>
    /// <param name="filePath">Path to the file</param>
    /// <returns>SHA-256 hash as string</returns>
    public string CalculateFileHash(string filePath)
    {
        try
        {
            using var sha256 = SHA256.Create();
            using var stream = File.OpenRead(filePath);
            var hash = sha256.ComputeHash(stream);
            return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
        }
        catch (Exception ex)
        {
            ConsoleHelper.WriteWarning($"Error calculating hash for {filePath}: {ex.Message}");
            return string.Empty;
        }
    }

    /// <summary>
    /// Checks if a driver is digitally signed
    /// </summary>
    /// <param name="filePath">Path to the driver file</param>
    /// <returns>True if the driver is signed, otherwise false</returns>
    private bool IsDriverSigned(string filePath)
    {
        try
        {
            // This is a simplified implementation
            // In a real application, you would use WinVerifyTrust API to check the signature
            return true; // Placeholder
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Gets detailed information about a driver
    /// </summary>
    /// <param name="driverName">Driver name</param>
    /// <returns>Driver information or null if not found</returns>
    public DriverInfo? GetDriverInfo(string driverName)
    {
        try
        {
            var drivers = GetInstalledDrivers();
            return drivers.FirstOrDefault(d => d.Name.Equals(driverName, StringComparison.OrdinalIgnoreCase));
        }
        catch (Exception ex)
        {
            ConsoleHelper.WriteError($"Error retrieving driver info: {ex.Message}");
            return null;
        }
    }

    /// <summary>
    /// Scans the system for vulnerable drivers
    /// </summary>
    /// <returns>List of vulnerable drivers</returns>
    public List<DriverInfo> ScanForVulnerableDrivers()
    {
        try
        {
            var allDrivers = GetInstalledDrivers();
            return allDrivers.Where(d => d.IsVulnerable).ToList();
        }
        catch (Exception ex)
        {
            ConsoleHelper.WriteError($"Error scanning for vulnerable drivers: {ex.Message}");
            return new List<DriverInfo>();
        }
    }
} 