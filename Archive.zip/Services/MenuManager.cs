using WindowsDriverProtection.Models;
using WindowsDriverProtection.Utils;

namespace WindowsDriverProtection.Services;

/// <summary>
/// Class for managing the application menu
/// </summary>
public class MenuManager
{
    private readonly DriverService _driverService;
    private readonly VulnerableDriverDatabase _vulnerableDriverDatabase;
    private readonly ConfigManager _configManager;
    private readonly NotificationService _notificationService;

    /// <summary>
    /// MenuManager constructor
    /// </summary>
    /// <param name="driverService">Driver service</param>
    /// <param name="vulnerableDriverDatabase">Vulnerable drivers database</param>
    /// <param name="configManager">Configuration manager</param>
    /// <param name="notificationService">Notification service</param>
    public MenuManager(
        DriverService driverService,
        VulnerableDriverDatabase vulnerableDriverDatabase,
        ConfigManager configManager,
        NotificationService notificationService)
    {
        _driverService = driverService;
        _vulnerableDriverDatabase = vulnerableDriverDatabase;
        _configManager = configManager;
        _notificationService = notificationService;
    }

    /// <summary>
    /// Displays the main menu and handles user input
    /// </summary>
    public void ShowMainMenu()
    {
        bool exit = false;

        while (!exit)
        {
            Console.Clear();
            ConsoleHelper.WriteHeader("Windows Driver Protection System");
            ConsoleHelper.WriteSeparator();
            
            Console.WriteLine("1. Scan system for vulnerable drivers");
            Console.WriteLine("2. View installed drivers");
            Console.WriteLine("3. View vulnerable drivers database");
            Console.WriteLine("4. Add driver to vulnerable database");
            Console.WriteLine("5. Remove driver from vulnerable database");
            Console.WriteLine("6. Update vulnerable drivers database");
            Console.WriteLine("7. Settings");
            Console.WriteLine("0. Exit");
            
            ConsoleHelper.WriteSeparator();
            Console.Write("Enter your choice: ");
            
            string? input = Console.ReadLine();
            
            switch (input)
            {
                case "1":
                    ScanSystem();
                    break;
                case "2":
                    ViewInstalledDrivers();
                    break;
                case "3":
                    ViewVulnerableDriversDatabase();
                    break;
                case "4":
                    AddDriverToDatabase();
                    break;
                case "5":
                    RemoveDriverFromDatabase();
                    break;
                case "6":
                    UpdateDatabase();
                    break;
                case "7":
                    ShowSettingsMenu();
                    break;
                case "0":
                    exit = true;
                    break;
                default:
                    ConsoleHelper.WriteWarning("Invalid option. Please try again.");
                    WaitForKeyPress();
                    break;
            }
        }
    }

    /// <summary>
    /// Scans the system for vulnerable drivers
    /// </summary>
    private void ScanSystem()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Scanning System for Vulnerable Drivers");
        ConsoleHelper.WriteSeparator();
        
        ConsoleHelper.WriteInfo("Retrieving installed drivers...");
        var drivers = _driverService.GetInstalledDrivers();
        
        if (drivers.Count == 0)
        {
            ConsoleHelper.WriteWarning("No drivers found or unable to access driver information.");
            WaitForKeyPress();
            return;
        }
        
        ConsoleHelper.WriteInfo($"Found {drivers.Count} drivers. Checking for vulnerabilities...");
        int vulnerableCount = 0;
        
        foreach (var driver in drivers)
        {
            // Calculate hash if not already done
            if (string.IsNullOrEmpty(driver.Hash) && !string.IsNullOrEmpty(driver.Path))
            {
                try
                {
                    driver.Hash = _driverService.CalculateFileHash(driver.Path);
                }
                catch (Exception ex)
                {
                    ConsoleHelper.WriteWarning($"Could not calculate hash for {driver.Name}: {ex.Message}");
                }
            }
            
            // Check if driver is in the vulnerable database
            if (!string.IsNullOrEmpty(driver.Hash))
            {
                var vulnerableInfo = _vulnerableDriverDatabase.CheckVulnerability(driver.Hash);
                if (vulnerableInfo != null)
                {
                    driver.IsVulnerable = true;
                    driver.VulnerabilityInfo = vulnerableInfo.Description;
                    driver.VulnerabilityCategory = vulnerableInfo.Category;
                    vulnerableCount++;
                    
                    ConsoleHelper.WriteError($"Vulnerable driver found: {driver.Name}");
                    ConsoleHelper.WriteError($"  Path: {driver.Path}");
                    ConsoleHelper.WriteError($"  Hash: {driver.Hash}");
                    ConsoleHelper.WriteError($"  Vulnerability: {vulnerableInfo.Description}");
                    ConsoleHelper.WriteError($"  Category: {vulnerableInfo.Category}");
                    ConsoleHelper.WriteSeparator();
                    
                    // Send notification
                    _notificationService.NotifyVulnerableDriverDetected(driver.Name, vulnerableInfo.Description);
                }
            }
        }
        
        ConsoleHelper.WriteSeparator();
        if (vulnerableCount > 0)
        {
            ConsoleHelper.WriteWarning($"Scan complete: Found {vulnerableCount} vulnerable drivers out of {drivers.Count} total drivers");
        }
        else
        {
            ConsoleHelper.WriteSuccess($"Scan complete: No vulnerable drivers found among {drivers.Count} drivers");
        }
        
        // Send notification about scan completion
        _notificationService.NotifyScanComplete(drivers.Count, vulnerableCount);
        
        WaitForKeyPress();
    }

    /// <summary>
    /// Displays a list of installed drivers
    /// </summary>
    private void ViewInstalledDrivers()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Installed Drivers");
        ConsoleHelper.WriteSeparator();
        
        ConsoleHelper.WriteInfo("Retrieving installed drivers...");
        var drivers = _driverService.GetInstalledDrivers();
        
        if (drivers.Count == 0)
        {
            ConsoleHelper.WriteWarning("No drivers found or unable to access driver information.");
            WaitForKeyPress();
            return;
        }
        
        ConsoleHelper.WriteInfo($"Found {drivers.Count} drivers:");
        ConsoleHelper.WriteSeparator();
        
        foreach (var driver in drivers)
        {
            ConsoleHelper.WriteDriverInfo(driver);
            ConsoleHelper.WriteSeparator();
        }
        
        WaitForKeyPress();
    }

    /// <summary>
    /// Displays the vulnerable drivers database
    /// </summary>
    private void ViewVulnerableDriversDatabase()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Vulnerable Drivers Database");
        ConsoleHelper.WriteSeparator();
        
        var vulnerableDrivers = _vulnerableDriverDatabase.VulnerableDrivers;
        
        if (vulnerableDrivers.Count == 0)
        {
            ConsoleHelper.WriteWarning("The vulnerable drivers database is empty.");
            WaitForKeyPress();
            return;
        }
        
        ConsoleHelper.WriteInfo($"Found {vulnerableDrivers.Count} entries in the database:");
        ConsoleHelper.WriteSeparator();
        
        foreach (var driver in vulnerableDrivers)
        {
            Console.WriteLine($"Name: {driver.Name}");
            Console.WriteLine($"Hash: {driver.Hash}");
            Console.WriteLine($"Category: {driver.Category}");
            Console.WriteLine($"Description: {driver.Description}");
            
            if (!string.IsNullOrEmpty(driver.CVE))
                Console.WriteLine($"CVE: {driver.CVE}");
                
            Console.WriteLine($"Severity: {driver.Severity}");
            
            if (!string.IsNullOrEmpty(driver.Notes))
                Console.WriteLine($"Notes: {driver.Notes}");
                
            ConsoleHelper.WriteSeparator();
        }
        
        WaitForKeyPress();
    }

    /// <summary>
    /// Adds a driver to the vulnerable drivers database
    /// </summary>
    private void AddDriverToDatabase()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Add Driver to Vulnerable Database");
        ConsoleHelper.WriteSeparator();
        
        Console.WriteLine("1. Add from installed drivers");
        Console.WriteLine("2. Add manually");
        Console.WriteLine("0. Back to main menu");
        
        ConsoleHelper.WriteSeparator();
        Console.Write("Enter your choice: ");
        
        string? input = Console.ReadLine();
        
        switch (input)
        {
            case "1":
                AddFromInstalledDrivers();
                break;
            case "2":
                AddDriverManually();
                break;
            case "0":
                return;
            default:
                ConsoleHelper.WriteWarning("Invalid option. Please try again.");
                WaitForKeyPress();
                break;
        }
    }

    /// <summary>
    /// Adds a driver from the list of installed drivers to the vulnerable drivers database
    /// </summary>
    private void AddFromInstalledDrivers()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Add from Installed Drivers");
        ConsoleHelper.WriteSeparator();
        
        ConsoleHelper.WriteInfo("Retrieving installed drivers...");
        var drivers = _driverService.GetInstalledDrivers();
        
        if (drivers.Count == 0)
        {
            ConsoleHelper.WriteWarning("No drivers found or unable to access driver information.");
            WaitForKeyPress();
            return;
        }
        
        // Display drivers with numbers
        for (int i = 0; i < drivers.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {drivers[i].Name} ({drivers[i].Path})");
        }
        
        ConsoleHelper.WriteSeparator();
        Console.Write("Enter the number of the driver to add (0 to cancel): ");
        
        if (!int.TryParse(Console.ReadLine(), out int driverIndex) || driverIndex < 0 || driverIndex > drivers.Count)
        {
            ConsoleHelper.WriteWarning("Invalid selection.");
            WaitForKeyPress();
            return;
        }
        
        if (driverIndex == 0)
            return;
            
        var selectedDriver = drivers[driverIndex - 1];
        
        // Calculate hash if not already done
        if (string.IsNullOrEmpty(selectedDriver.Hash) && !string.IsNullOrEmpty(selectedDriver.Path))
        {
            try
            {
                selectedDriver.Hash = _driverService.CalculateFileHash(selectedDriver.Path);
            }
            catch (Exception ex)
            {
                ConsoleHelper.WriteWarning($"Could not calculate hash for {selectedDriver.Name}: {ex.Message}");
                WaitForKeyPress();
                return;
            }
        }
        
        if (string.IsNullOrEmpty(selectedDriver.Hash))
        {
            ConsoleHelper.WriteWarning("Cannot add driver without a valid hash.");
            WaitForKeyPress();
            return;
        }
        
        // Get vulnerability details
        Console.Write("Enter vulnerability description: ");
        string description = Console.ReadLine() ?? string.Empty;
        
        Console.Write("Enter vulnerability category: ");
        string category = Console.ReadLine() ?? string.Empty;
        
        Console.Write("Enter CVE (if applicable): ");
        string cve = Console.ReadLine() ?? string.Empty;
        
        Console.Write("Enter severity (Critical, High, Medium, Low): ");
        string severity = Console.ReadLine() ?? "High";
        
        Console.Write("Enter additional notes: ");
        string notes = Console.ReadLine() ?? string.Empty;
        
        // Create and add the vulnerable driver info
        var vulnerableDriverInfo = new VulnerableDriverInfo
        {
            Name = selectedDriver.Name,
            Hash = selectedDriver.Hash,
            Description = description,
            Category = category,
            CVE = cve,
            DateAdded = DateTime.Now,
            Severity = severity,
            Notes = notes
        };
        
        _vulnerableDriverDatabase.AddVulnerableDriver(vulnerableDriverInfo);
        ConsoleHelper.WriteSuccess($"Driver {selectedDriver.Name} added to the vulnerable drivers database");
        
        WaitForKeyPress();
    }

    /// <summary>
    /// Adds a driver manually to the vulnerable drivers database
    /// </summary>
    private void AddDriverManually()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Add Driver Manually");
        ConsoleHelper.WriteSeparator();
        
        Console.Write("Enter driver name: ");
        string name = Console.ReadLine() ?? string.Empty;
        
        if (string.IsNullOrWhiteSpace(name))
        {
            ConsoleHelper.WriteWarning("Driver name cannot be empty.");
            WaitForKeyPress();
            return;
        }
        
        Console.Write("Enter driver SHA-256 hash: ");
        string hash = Console.ReadLine() ?? string.Empty;
        
        if (string.IsNullOrWhiteSpace(hash))
        {
            ConsoleHelper.WriteWarning("Driver hash cannot be empty.");
            WaitForKeyPress();
            return;
        }
        
        Console.Write("Enter vulnerability description: ");
        string description = Console.ReadLine() ?? string.Empty;
        
        Console.Write("Enter vulnerability category: ");
        string category = Console.ReadLine() ?? string.Empty;
        
        Console.Write("Enter CVE (if applicable): ");
        string cve = Console.ReadLine() ?? string.Empty;
        
        Console.Write("Enter severity (Critical, High, Medium, Low): ");
        string severity = Console.ReadLine() ?? "High";
        
        Console.Write("Enter additional notes: ");
        string notes = Console.ReadLine() ?? string.Empty;
        
        // Create and add the vulnerable driver info
        var vulnerableDriverInfo = new VulnerableDriverInfo
        {
            Name = name,
            Hash = hash,
            Description = description,
            Category = category,
            CVE = cve,
            DateAdded = DateTime.Now,
            Severity = severity,
            Notes = notes
        };
        
        _vulnerableDriverDatabase.AddVulnerableDriver(vulnerableDriverInfo);
        
        WaitForKeyPress();
    }

    /// <summary>
    /// Removes a driver from the vulnerable drivers database
    /// </summary>
    private void RemoveDriverFromDatabase()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Remove Driver from Vulnerable Database");
        ConsoleHelper.WriteSeparator();
        
        var vulnerableDrivers = _vulnerableDriverDatabase.VulnerableDrivers;
        
        if (vulnerableDrivers.Count == 0)
        {
            ConsoleHelper.WriteWarning("The vulnerable drivers database is empty.");
            WaitForKeyPress();
            return;
        }
        
        // Display drivers with numbers
        for (int i = 0; i < vulnerableDrivers.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {vulnerableDrivers[i].Name} ({vulnerableDrivers[i].Hash})");
        }
        
        ConsoleHelper.WriteSeparator();
        Console.Write("Enter the number of the driver to remove (0 to cancel): ");
        
        if (!int.TryParse(Console.ReadLine(), out int driverIndex) || driverIndex < 0 || driverIndex > vulnerableDrivers.Count)
        {
            ConsoleHelper.WriteWarning("Invalid selection.");
            WaitForKeyPress();
            return;
        }
        
        if (driverIndex == 0)
            return;
            
        var selectedDriver = vulnerableDrivers[driverIndex - 1];
        
        Console.Write($"Are you sure you want to remove {selectedDriver.Name} from the database? (y/n): ");
        string? confirmation = Console.ReadLine()?.ToLower();
        
        if (confirmation == "y" || confirmation == "yes")
        {
            _vulnerableDriverDatabase.RemoveVulnerableDriver(selectedDriver.Hash);
        }
        else
        {
            ConsoleHelper.WriteInfo("Operation cancelled.");
        }
        
        WaitForKeyPress();
    }

    /// <summary>
    /// Updates the vulnerable drivers database
    /// </summary>
    private async void UpdateDatabase()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Update Vulnerable Drivers Database");
        ConsoleHelper.WriteSeparator();
        
        ConsoleHelper.WriteInfo("Updating database from online sources...");
        bool success = await _vulnerableDriverDatabase.UpdateDatabaseFromOnlineSource();
        
        if (success)
        {
            ConsoleHelper.WriteSuccess("Database updated successfully.");
            _notificationService.NotifyDatabaseUpdate(true, "Database updated successfully");
        }
        else
        {
            ConsoleHelper.WriteError("Failed to update database.");
            _notificationService.NotifyDatabaseUpdate(false, "Failed to update database");
        }
        
        WaitForKeyPress();
    }

    /// <summary>
    /// Displays the settings menu
    /// </summary>
    private void ShowSettingsMenu()
    {
        bool exit = false;
        
        while (!exit)
        {
            Console.Clear();
            ConsoleHelper.WriteHeader("Settings");
            ConsoleHelper.WriteSeparator();
            
            Console.WriteLine($"1. Enable notifications: {(_configManager.Config.EnableNotifications ? "Enabled" : "Disabled")}");
            Console.WriteLine($"2. Database path: {_configManager.Config.DatabasePath}");
            Console.WriteLine($"3. Auto-update database: {(_configManager.Config.AutoUpdateDatabase ? "Enabled" : "Disabled")}");
            Console.WriteLine($"4. Update interval (days): {_configManager.Config.UpdateIntervalDays}");
            Console.WriteLine("5. Save settings");
            Console.WriteLine("0. Back to main menu");
            
            ConsoleHelper.WriteSeparator();
            Console.Write("Enter your choice: ");
            
            string? input = Console.ReadLine();
            
            switch (input)
            {
                case "1":
                    _configManager.Config.EnableNotifications = !_configManager.Config.EnableNotifications;
                    break;
                case "2":
                    Console.Write("Enter new database path: ");
                    string? newPath = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(newPath))
                    {
                        _configManager.Config.DatabasePath = newPath;
                    }
                    break;
                case "3":
                    _configManager.Config.AutoUpdateDatabase = !_configManager.Config.AutoUpdateDatabase;
                    break;
                case "4":
                    Console.Write("Enter update interval in days: ");
                    if (int.TryParse(Console.ReadLine(), out int days) && days > 0)
                    {
                        _configManager.Config.UpdateIntervalDays = days;
                    }
                    else
                    {
                        ConsoleHelper.WriteWarning("Invalid value. Please enter a positive number.");
                        WaitForKeyPress();
                    }
                    break;
                case "5":
                    _configManager.SaveConfig();
                    ConsoleHelper.WriteSuccess("Settings saved successfully.");
                    WaitForKeyPress();
                    break;
                case "0":
                    exit = true;
                    break;
                default:
                    ConsoleHelper.WriteWarning("Invalid option. Please try again.");
                    WaitForKeyPress();
                    break;
            }
        }
    }

    /// <summary>
    /// Waits for a key press
    /// </summary>
    private void WaitForKeyPress()
    {
        Console.WriteLine("\nPress any key to continue...");
        Console.ReadKey(true);
    }
} 