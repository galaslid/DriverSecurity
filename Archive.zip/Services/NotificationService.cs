using WindowsDriverProtection.Models;
using WindowsDriverProtection.Utils;

namespace WindowsDriverProtection.Services;

/// <summary>
/// Service for sending notifications to the user
/// </summary>
public class NotificationService
{
    private readonly ConfigManager _configManager;

    /// <summary>
    /// NotificationService constructor
    /// </summary>
    /// <param name="configManager">Configuration manager</param>
    public NotificationService(ConfigManager configManager)
    {
        _configManager = configManager;
    }

    /// <summary>
    /// Sends a notification about a vulnerable driver
    /// </summary>
    /// <param name="driverName">Driver name</param>
    /// <param name="vulnerabilityInfo">Vulnerability information</param>
    public void NotifyVulnerableDriverDetected(string driverName, string vulnerabilityInfo)
    {
        if (!_configManager.Config.EnableNotifications)
            return;

        ConsoleHelper.WriteError($"SECURITY ALERT: Vulnerable driver detected!");
        ConsoleHelper.WriteError($"Driver: {driverName}");
        ConsoleHelper.WriteError($"Vulnerability: {vulnerabilityInfo}");
        ConsoleHelper.WriteError("This driver may be exploited to gain elevated privileges on your system.");
        ConsoleHelper.WriteError("Recommendation: Consider uninstalling or updating this driver if possible.");
        
        // TODO: Implement Windows notification system integration
        // For example, using Windows Toast notifications
    }

    /// <summary>
    /// Sends a notification about a system scan completion
    /// </summary>
    /// <param name="totalDrivers">Total number of drivers scanned</param>
    /// <param name="vulnerableDrivers">Number of vulnerable drivers found</param>
    public void NotifyScanComplete(int totalDrivers, int vulnerableDrivers)
    {
        if (!_configManager.Config.EnableNotifications)
            return;

        if (vulnerableDrivers > 0)
        {
            ConsoleHelper.WriteWarning($"Scan complete: {vulnerableDrivers} vulnerable drivers found out of {totalDrivers} total drivers");
        }
        else
        {
            ConsoleHelper.WriteSuccess($"Scan complete: No vulnerable drivers found among {totalDrivers} drivers");
        }
        
        // TODO: Implement Windows notification system integration
    }

    /// <summary>
    /// Sends a notification about database update
    /// </summary>
    /// <param name="success">Whether the update was successful</param>
    /// <param name="message">Additional message</param>
    public void NotifyDatabaseUpdate(bool success, string message)
    {
        if (!_configManager.Config.EnableNotifications)
            return;

        if (success)
        {
            ConsoleHelper.WriteSuccess($"Database update: {message}");
        }
        else
        {
            ConsoleHelper.WriteError($"Database update failed: {message}");
        }
        
        // TODO: Implement Windows notification system integration
    }
} 