using System.Text.Json;
using WindowsDriverProtection.Models;
using WindowsDriverProtection.Utils;

namespace WindowsDriverProtection.Services;

/// <summary>
/// Class for working with the vulnerable drivers database
/// </summary>
public class VulnerableDriverDatabase
{
    private readonly ConfigManager _configManager;
    private List<VulnerableDriverInfo> _vulnerableDrivers = new();

    /// <summary>
    /// VulnerableDriverDatabase constructor
    /// </summary>
    /// <param name="configManager">Configuration manager</param>
    public VulnerableDriverDatabase(ConfigManager configManager)
    {
        _configManager = configManager;
        LoadDatabase();
    }

    /// <summary>
    /// List of vulnerable drivers
    /// </summary>
    public IReadOnlyList<VulnerableDriverInfo> VulnerableDrivers => _vulnerableDrivers;

    /// <summary>
    /// Loads database from file
    /// </summary>
    private void LoadDatabase()
    {
        try
        {
            string dbPath = _configManager.Config.DatabasePath;
            
            if (File.Exists(dbPath))
            {
                string json = File.ReadAllText(dbPath);
                _vulnerableDrivers = JsonSerializer.Deserialize<List<VulnerableDriverInfo>>(json) ?? new List<VulnerableDriverInfo>();
                ConsoleHelper.WriteInfo($"Loaded {_vulnerableDrivers.Count} entries from the vulnerable drivers database");
            }
            else
            {
                ConsoleHelper.WriteWarning("Vulnerable drivers database not found. Creating a new database.");
                _vulnerableDrivers = new List<VulnerableDriverInfo>();
                SaveDatabase();
            }
        }
        catch (Exception ex)
        {
            ConsoleHelper.WriteError($"Error loading database: {ex.Message}");
            _vulnerableDrivers = new List<VulnerableDriverInfo>();
        }
    }

    /// <summary>
    /// Saves database to file
    /// </summary>
    public void SaveDatabase()
    {
        try
        {
            string dbPath = _configManager.Config.DatabasePath;
            string json = JsonSerializer.Serialize(_vulnerableDrivers, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(dbPath, json);
            ConsoleHelper.WriteSuccess("Vulnerable drivers database successfully saved");
        }
        catch (Exception ex)
        {
            ConsoleHelper.WriteError($"Error saving database: {ex.Message}");
        }
    }

    /// <summary>
    /// Adds a vulnerable driver entry to the database
    /// </summary>
    /// <param name="driverInfo">Vulnerable driver information</param>
    public void AddVulnerableDriver(VulnerableDriverInfo driverInfo)
    {
        if (_vulnerableDrivers.Any(d => d.Hash == driverInfo.Hash))
        {
            ConsoleHelper.WriteWarning($"Driver with hash {driverInfo.Hash} already exists in the database");
            return;
        }

        _vulnerableDrivers.Add(driverInfo);
        SaveDatabase();
        ConsoleHelper.WriteSuccess($"Driver {driverInfo.Name} added to the vulnerable drivers database");
    }

    /// <summary>
    /// Removes a vulnerable driver entry from the database
    /// </summary>
    /// <param name="hash">Driver hash</param>
    public void RemoveVulnerableDriver(string hash)
    {
        int count = _vulnerableDrivers.RemoveAll(d => d.Hash == hash);
        
        if (count > 0)
        {
            SaveDatabase();
            ConsoleHelper.WriteSuccess($"Driver with hash {hash} removed from the vulnerable drivers database");
        }
        else
        {
            ConsoleHelper.WriteWarning($"Driver with hash {hash} not found in the database");
        }
    }

    /// <summary>
    /// Checks if a driver is vulnerable
    /// </summary>
    /// <param name="hash">Driver hash</param>
    /// <returns>Vulnerability information or null if the driver is not vulnerable</returns>
    public VulnerableDriverInfo? CheckVulnerability(string hash)
    {
        return _vulnerableDrivers.FirstOrDefault(d => d.Hash == hash);
    }

    /// <summary>
    /// Updates the database from an online source
    /// </summary>
    /// <returns>True if update successful, otherwise False</returns>
    public async Task<bool> UpdateDatabaseFromOnlineSource()
    {
        try
        {
            ConsoleHelper.WriteInfo("Updating vulnerable drivers database...");
            
            // TODO: Implement update from online source
            // For example, download from GitHub or other repository
            
            // Example code for downloading:
            // using HttpClient client = new();
            // string json = await client.GetStringAsync("https://example.com/vulnerable_drivers.json");
            // _vulnerableDrivers = JsonSerializer.Deserialize<List<VulnerableDriverInfo>>(json) ?? new List<VulnerableDriverInfo>();
            
            // Temporary placeholder
            await Task.Delay(1000);
            
            _configManager.Config.LastDatabaseUpdate = DateTime.Now;
            _configManager.SaveConfig();
            SaveDatabase();
            
            ConsoleHelper.WriteSuccess("Vulnerable drivers database successfully updated");
            return true;
        }
        catch (Exception ex)
        {
            ConsoleHelper.WriteError($"Error updating database: {ex.Message}");
            return false;
        }
    }
} 