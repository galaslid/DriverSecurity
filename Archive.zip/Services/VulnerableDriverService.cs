using System.Text.Json;
using System.Text.Json.Serialization;
using WindowsDriverProtection.Models;

namespace WindowsDriverProtection.Services;

/// <summary>
/// Сервис для работы с базой данных уязвимых драйверов
/// </summary>
public class VulnerableDriverService
{
    private readonly HttpClient _httpClient;
    private const string ApiUrl = "https://www.loldrivers.io/api/drivers.json";
    
    private static List<VulnerableDriver>? _cachedDrivers;
    private static DateTime _lastCacheUpdate;
    private const int CacheExpirationMinutes = 60;
    
    /// <summary>
    /// Конструктор сервиса
    /// </summary>
    public VulnerableDriverService()
    {
        _httpClient = new HttpClient();
        _httpClient.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
        _httpClient.DefaultRequestHeaders.Add("Accept", "application/json");
    }

    /// <summary>
    /// Получает список уязвимых драйверов из базы данных
    /// </summary>
    public async Task<List<VulnerableDriver>> GetVulnerableDriversAsync()
    {
        if (_cachedDrivers != null && DateTime.Now.Subtract(_lastCacheUpdate).TotalMinutes < CacheExpirationMinutes)
        {
            return _cachedDrivers;
        }

        try
        {
            var response = await _httpClient.GetAsync(ApiUrl);
            response.EnsureSuccessStatusCode();
            
            var jsonContent = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
            };
            
            var drivers = JsonSerializer.Deserialize<List<VulnerableDriver>>(jsonContent, options);
            
            if (drivers != null && drivers.Any())
            {
                _cachedDrivers = drivers;
                _lastCacheUpdate = DateTime.Now;
                return drivers;
            }
            
            return new List<VulnerableDriver>();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при получении данных об уязвимых драйверах: {ex.Message}");
            return new List<VulnerableDriver>();
        }
    }

    /// <summary>
    /// Проверяет, является ли драйвер уязвимым
    /// </summary>
    public async Task<(bool IsVulnerable, VulnerableDriver? VulnerabilityInfo)> IsDriverVulnerableAsync(DriverInfo driver)
    {
        if (string.IsNullOrEmpty(driver.Hash) && string.IsNullOrEmpty(driver.Name))
            return (false, null);
            
        var vulnerableDrivers = await GetVulnerableDriversAsync();
        
        foreach (var vulnDriver in vulnerableDrivers)
        {
            // Проверяем по имени файла
            if (vulnDriver.Tags.Any() && 
                !string.IsNullOrEmpty(driver.Name) && 
                driver.Name.Equals(vulnDriver.Tags[0], StringComparison.OrdinalIgnoreCase))
            {
                return (true, vulnDriver);
            }
            
            // Проверяем по хешу
            if (!string.IsNullOrEmpty(driver.Hash) && 
                vulnDriver.GetKnownVulnerableSamples().Contains(driver.Hash, StringComparer.OrdinalIgnoreCase))
            {
                return (true, vulnDriver);
            }
        }
        
        return (false, null);
    }

    /// <summary>
    /// Проверяет список драйверов на уязвимости
    /// </summary>
    public async Task<List<DriverInfo>> CheckDriversForVulnerabilitiesAsync(List<DriverInfo> drivers)
    {
        var vulnerableDrivers = await GetVulnerableDriversAsync();
        
        foreach (var driver in drivers)
        {
            foreach (var vulnDriver in vulnerableDrivers)
            {
                // Проверяем по имени файла
                if (vulnDriver.Tags.Any() && 
                    !string.IsNullOrEmpty(driver.Name) && 
                    driver.Name.Equals(vulnDriver.Tags[0], StringComparison.OrdinalIgnoreCase))
                {
                    driver.IsVulnerable = true;
                    driver.VulnerabilityInfo = vulnDriver.Commands.Description;
                    driver.VulnerabilityCategory = vulnDriver.Category;
                    break;
                }
                
                // Проверяем по хешу
                if (!string.IsNullOrEmpty(driver.Hash) && 
                    vulnDriver.GetKnownVulnerableSamples().Contains(driver.Hash, StringComparer.OrdinalIgnoreCase))
                {
                    driver.IsVulnerable = true;
                    driver.VulnerabilityInfo = vulnDriver.Commands.Description;
                    driver.VulnerabilityCategory = vulnDriver.Category;
                    break;
                }
            }
        }
        
        return drivers;
    }
} 