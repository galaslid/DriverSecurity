using WindowsDriverProtection.Models;
using WindowsDriverProtection.Services;
using WindowsDriverProtection.Utils;

namespace WindowsDriverProtection.UI;

/// <summary>
/// Класс для управления меню приложения
/// </summary>
public class MenuManager
{
    private readonly DriverService _driverService;
    private readonly VulnerableDriverDatabase _vulnerableDriverDatabase;
    private readonly ConfigManager _configManager;
    private readonly NotificationService _notificationService;

    /// <summary>
    /// Конструктор класса MenuManager
    /// </summary>
    /// <param name="driverService">Сервис для работы с драйверами</param>
    /// <param name="vulnerableDriverDatabase">База данных уязвимых драйверов</param>
    /// <param name="configManager">Менеджер конфигурации</param>
    /// <param name="notificationService">Сервис уведомлений</param>
    public MenuManager(
        DriverService driverService,
        VulnerableDriverDatabase vulnerableDriverDatabase,
        ConfigManager configManager,
        NotificationService notificationService)
    {
        _driverService = driverService;
        _vulnerableDriverDatabase = vulnerableDriverDatabase;
        _configManager = configManager;
        _notificationService = notificationService;
    }

    /// <summary>
    /// Отображает главное меню и обрабатывает выбор пользователя
    /// </summary>
    public void ShowMainMenu()
    {
        bool exit = false;

        while (!exit)
        {
            Console.Clear();
            ConsoleHelper.WriteHeader("Система защиты от уязвимых драйверов Windows");
            
            Console.WriteLine("1. Сканировать систему на наличие уязвимых драйверов");
            Console.WriteLine("2. Просмотреть список установленных драйверов");
            Console.WriteLine("3. Просмотреть базу данных уязвимых драйверов");
            Console.WriteLine("4. Добавить драйвер в базу данных уязвимых драйверов");
            Console.WriteLine("5. Удалить драйвер из базы данных уязвимых драйверов");
            Console.WriteLine("6. Обновить базу данных уязвимых драйверов");
            Console.WriteLine("7. Настройки");
            Console.WriteLine("8. Выход");
            
            ConsoleHelper.WriteSeparator();
            Console.Write("Выберите пункт меню: ");
            
            if (int.TryParse(Console.ReadLine(), out int choice))
            {
                switch (choice)
                {
                    case 1:
                        ScanSystem();
                        break;
                    case 2:
                        ShowDriversList();
                        break;
                    case 3:
                        ShowVulnerableDriversDatabase();
                        break;
                    case 4:
                        AddDriverToDatabase();
                        break;
                    case 5:
                        RemoveDriverFromDatabase();
                        break;
                    case 6:
                        UpdateDatabase();
                        break;
                    case 7:
                        ShowSettings();
                        break;
                    case 8:
                        exit = true;
                        break;
                    default:
                        ConsoleHelper.WriteWarning("Неверный выбор. Пожалуйста, выберите пункт из меню.");
                        WaitForKeyPress();
                        break;
                }
            }
            else
            {
                ConsoleHelper.WriteWarning("Неверный ввод. Пожалуйста, введите число.");
                WaitForKeyPress();
            }
        }
    }

    /// <summary>
    /// Сканирует систему на наличие уязвимых драйверов
    /// </summary>
    private void ScanSystem()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Сканирование системы");
        
        ConsoleHelper.WriteInfo("Получение списка установленных драйверов...");
        var drivers = _driverService.GetAllDrivers();
        
        ConsoleHelper.WriteInfo($"Найдено {drivers.Count} драйверов. Проверка на уязвимости...");
        int vulnerableCount = 0;
        
        foreach (var driver in drivers)
        {
            var vulnerabilityInfo = _vulnerableDriverDatabase.CheckVulnerability(driver.Hash);
            
            if (vulnerabilityInfo != null)
            {
                driver.IsVulnerable = true;
                driver.VulnerabilityInfo = vulnerabilityInfo.Description;
                driver.VulnerabilityCategory = vulnerabilityInfo.Category;
                vulnerableCount++;
                
                _notificationService.NotifyVulnerableDriverDetected(driver);
            }
        }
        
        _notificationService.NotifyScanCompleted(vulnerableCount, drivers.Count);
        
        if (vulnerableCount > 0)
        {
            ConsoleHelper.WriteWarning($"Обнаружено {vulnerableCount} уязвимых драйверов из {drivers.Count}");
            
            Console.WriteLine("\nСписок уязвимых драйверов:");
            foreach (var driver in drivers.Where(d => d.IsVulnerable))
            {
                ConsoleHelper.WriteSeparator();
                ConsoleHelper.WriteDriverInfo(driver);
            }
        }
        else
        {
            ConsoleHelper.WriteSuccess($"Уязвимых драйверов не обнаружено (проверено {drivers.Count})");
        }
        
        WaitForKeyPress();
    }

    /// <summary>
    /// Отображает список установленных драйверов
    /// </summary>
    private void ShowDriversList()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Список установленных драйверов");
        
        ConsoleHelper.WriteInfo("Получение списка установленных драйверов...");
        var drivers = _driverService.GetAllDrivers();
        
        ConsoleHelper.WriteInfo($"Найдено {drivers.Count} драйверов:");
        
        foreach (var driver in drivers)
        {
            ConsoleHelper.WriteSeparator();
            ConsoleHelper.WriteDriverInfo(driver);
        }
        
        WaitForKeyPress();
    }

    /// <summary>
    /// Отображает базу данных уязвимых драйверов
    /// </summary>
    private void ShowVulnerableDriversDatabase()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("База данных уязвимых драйверов");
        
        var vulnerableDrivers = _vulnerableDriverDatabase.VulnerableDrivers;
        
        if (vulnerableDrivers.Count == 0)
        {
            ConsoleHelper.WriteWarning("База данных уязвимых драйверов пуста.");
        }
        else
        {
            ConsoleHelper.WriteInfo($"В базе данных {vulnerableDrivers.Count} записей:");
            
            foreach (var driver in vulnerableDrivers)
            {
                ConsoleHelper.WriteSeparator();
                Console.WriteLine($"Имя: {driver.Name}");
                Console.WriteLine($"Хеш (SHA-256): {driver.Hash}");
                Console.WriteLine($"Категория: {driver.Category}");
                Console.WriteLine($"Описание: {driver.Description}");
                Console.WriteLine($"Производитель: {driver.Vendor}");
                Console.WriteLine($"Версия: {driver.Version}");
                Console.WriteLine($"Уровень опасности: {driver.SeverityLevel}/10");
                
                if (driver.CveIds.Count > 0)
                {
                    Console.WriteLine($"CVE ID: {string.Join(", ", driver.CveIds)}");
                }
                
                if (!string.IsNullOrEmpty(driver.ReferenceUrl))
                {
                    Console.WriteLine($"Ссылка: {driver.ReferenceUrl}");
                }
            }
        }
        
        ConsoleHelper.WriteInfo($"\nПоследнее обновление базы данных: {_configManager.Config.LastDatabaseUpdate}");
        
        WaitForKeyPress();
    }

    /// <summary>
    /// Добавляет драйвер в базу данных уязвимых драйверов
    /// </summary>
    private void AddDriverToDatabase()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Добавление драйвера в базу данных");
        
        Console.WriteLine("1. Выбрать из установленных драйверов");
        Console.WriteLine("2. Ввести информацию вручную");
        Console.WriteLine("3. Вернуться в главное меню");
        
        Console.Write("\nВыберите опцию: ");
        
        if (int.TryParse(Console.ReadLine(), out int choice))
        {
            switch (choice)
            {
                case 1:
                    AddExistingDriverToDatabase();
                    break;
                case 2:
                    AddManualDriverToDatabase();
                    break;
                case 3:
                    return;
                default:
                    ConsoleHelper.WriteWarning("Неверный выбор.");
                    WaitForKeyPress();
                    break;
            }
        }
        else
        {
            ConsoleHelper.WriteWarning("Неверный ввод. Пожалуйста, введите число.");
            WaitForKeyPress();
        }
    }

    /// <summary>
    /// Добавляет существующий драйвер в базу данных уязвимых драйверов
    /// </summary>
    private void AddExistingDriverToDatabase()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Добавление существующего драйвера в базу данных");
        
        ConsoleHelper.WriteInfo("Получение списка установленных драйверов...");
        var drivers = _driverService.GetAllDrivers();
        
        for (int i = 0; i < drivers.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {drivers[i].Name} ({drivers[i].Path})");
        }
        
        Console.Write("\nВыберите драйвер (номер) или 0 для отмены: ");
        
        if (int.TryParse(Console.ReadLine(), out int driverIndex) && driverIndex > 0 && driverIndex <= drivers.Count)
        {
            var selectedDriver = drivers[driverIndex - 1];
            
            Console.Clear();
            ConsoleHelper.WriteInfo($"Выбран драйвер: {selectedDriver.Name}");
            ConsoleHelper.WriteDriverInfo(selectedDriver);
            
            Console.Write("\nВведите категорию уязвимости: ");
            string category = Console.ReadLine() ?? string.Empty;
            
            Console.Write("Введите описание уязвимости: ");
            string description = Console.ReadLine() ?? string.Empty;
            
            Console.Write("Введите уровень опасности (1-10): ");
            if (!int.TryParse(Console.ReadLine(), out int severityLevel) || severityLevel < 1 || severityLevel > 10)
            {
                severityLevel = 5;
                ConsoleHelper.WriteWarning("Неверный ввод. Установлен уровень опасности 5.");
            }
            
            Console.Write("Введите ссылку на дополнительную информацию (опционально): ");
            string referenceUrl = Console.ReadLine() ?? string.Empty;
            
            var vulnerableDriver = new VulnerableDriverInfo
            {
                Name = selectedDriver.Name,
                Hash = selectedDriver.Hash,
                Category = category,
                Description = description,
                SeverityLevel = severityLevel,
                ReferenceUrl = referenceUrl,
                Vendor = selectedDriver.DisplayName,
                Version = "Unknown",
                DiscoveryDate = DateTime.Now,
                CveIds = new List<string>()
            };
            
            _vulnerableDriverDatabase.AddVulnerableDriver(vulnerableDriver);
        }
        else if (driverIndex != 0)
        {
            ConsoleHelper.WriteWarning("Неверный выбор драйвера.");
            WaitForKeyPress();
        }
    }

    /// <summary>
    /// Добавляет драйвер в базу данных уязвимых драйверов вручную
    /// </summary>
    private void AddManualDriverToDatabase()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Добавление драйвера в базу данных вручную");
        
        Console.Write("Введите имя драйвера: ");
        string name = Console.ReadLine() ?? string.Empty;
        
        Console.Write("Введите хеш драйвера (SHA-256): ");
        string hash = Console.ReadLine() ?? string.Empty;
        
        Console.Write("Введите категорию уязвимости: ");
        string category = Console.ReadLine() ?? string.Empty;
        
        Console.Write("Введите описание уязвимости: ");
        string description = Console.ReadLine() ?? string.Empty;
        
        Console.Write("Введите производителя: ");
        string vendor = Console.ReadLine() ?? string.Empty;
        
        Console.Write("Введите версию драйвера: ");
        string version = Console.ReadLine() ?? string.Empty;
        
        Console.Write("Введите уровень опасности (1-10): ");
        if (!int.TryParse(Console.ReadLine(), out int severityLevel) || severityLevel < 1 || severityLevel > 10)
        {
            severityLevel = 5;
            ConsoleHelper.WriteWarning("Неверный ввод. Установлен уровень опасности 5.");
        }
        
        Console.Write("Введите ссылку на дополнительную информацию (опционально): ");
        string referenceUrl = Console.ReadLine() ?? string.Empty;
        
        var vulnerableDriver = new VulnerableDriverInfo
        {
            Name = name,
            Hash = hash,
            Category = category,
            Description = description,
            SeverityLevel = severityLevel,
            ReferenceUrl = referenceUrl,
            Vendor = vendor,
            Version = version,
            DiscoveryDate = DateTime.Now,
            CveIds = new List<string>()
        };
        
        _vulnerableDriverDatabase.AddVulnerableDriver(vulnerableDriver);
    }

    /// <summary>
    /// Удаляет драйвер из базы данных уязвимых драйверов
    /// </summary>
    private void RemoveDriverFromDatabase()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Удаление драйвера из базы данных");
        
        var vulnerableDrivers = _vulnerableDriverDatabase.VulnerableDrivers;
        
        if (vulnerableDrivers.Count == 0)
        {
            ConsoleHelper.WriteWarning("База данных уязвимых драйверов пуста.");
            WaitForKeyPress();
            return;
        }
        
        for (int i = 0; i < vulnerableDrivers.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {vulnerableDrivers[i].Name} ({vulnerableDrivers[i].Hash})");
        }
        
        Console.Write("\nВыберите драйвер для удаления (номер) или 0 для отмены: ");
        
        if (int.TryParse(Console.ReadLine(), out int driverIndex) && driverIndex > 0 && driverIndex <= vulnerableDrivers.Count)
        {
            var selectedDriver = vulnerableDrivers[driverIndex - 1];
            
            Console.Clear();
            ConsoleHelper.WriteInfo($"Выбран драйвер: {selectedDriver.Name}");
            Console.WriteLine($"Хеш: {selectedDriver.Hash}");
            Console.WriteLine($"Категория: {selectedDriver.Category}");
            Console.WriteLine($"Описание: {selectedDriver.Description}");
            
            Console.Write("\nВы уверены, что хотите удалить этот драйвер из базы данных? (д/н): ");
            string confirmation = Console.ReadLine()?.ToLower() ?? string.Empty;
            
            if (confirmation == "д" || confirmation == "да" || confirmation == "y" || confirmation == "yes")
            {
                _vulnerableDriverDatabase.RemoveVulnerableDriver(selectedDriver.Hash);
            }
            else
            {
                ConsoleHelper.WriteInfo("Операция отменена.");
                WaitForKeyPress();
            }
        }
        else if (driverIndex != 0)
        {
            ConsoleHelper.WriteWarning("Неверный выбор драйвера.");
            WaitForKeyPress();
        }
    }

    /// <summary>
    /// Обновляет базу данных уязвимых драйверов
    /// </summary>
    private async void UpdateDatabase()
    {
        Console.Clear();
        ConsoleHelper.WriteHeader("Обновление базы данных");
        
        ConsoleHelper.WriteInfo("Обновление базы данных уязвимых драйверов...");
        
        bool success = await _vulnerableDriverDatabase.UpdateDatabaseFromOnlineSource();
        
        if (success)
        {
            _notificationService.NotifyDatabaseUpdated();
        }
        else
        {
            _notificationService.NotifyError("Не удалось обновить базу данных уязвимых драйверов");
        }
        
        WaitForKeyPress();
    }

    /// <summary>
    /// Отображает настройки приложения
    /// </summary>
    private void ShowSettings()
    {
        bool exit = false;
        
        while (!exit)
        {
            Console.Clear();
            ConsoleHelper.WriteHeader("Настройки");
            
            Console.WriteLine($"1. Уведомления: {(_configManager.Config.EnableNotifications ? "Включены" : "Выключены")}");
            Console.WriteLine($"2. Автоматическое обновление базы данных: {(_configManager.Config.AutoUpdateDatabase ? "Включено" : "Выключено")}");
            Console.WriteLine($"3. Интервал сканирования: {_configManager.Config.ScanIntervalMinutes} минут");
            Console.WriteLine($"4. Путь к базе данных: {_configManager.Config.DatabasePath}");
            Console.WriteLine("5. Вернуться в главное меню");
            
            Console.Write("\nВыберите настройку для изменения: ");
            
            if (int.TryParse(Console.ReadLine(), out int choice))
            {
                switch (choice)
                {
                    case 1:
                        _configManager.Config.EnableNotifications = !_configManager.Config.EnableNotifications;
                        _configManager.SaveConfig();
                        break;
                    case 2:
                        _configManager.Config.AutoUpdateDatabase = !_configManager.Config.AutoUpdateDatabase;
                        _configManager.SaveConfig();
                        break;
                    case 3:
                        Console.Write("Введите интервал сканирования в минутах: ");
                        if (int.TryParse(Console.ReadLine(), out int interval) && interval > 0)
                        {
                            _configManager.Config.ScanIntervalMinutes = interval;
                            _configManager.SaveConfig();
                        }
                        else
                        {
                            ConsoleHelper.WriteWarning("Неверный ввод. Интервал должен быть положительным числом.");
                            WaitForKeyPress();
                        }
                        break;
                    case 4:
                        Console.Write("Введите путь к базе данных: ");
                        string path = Console.ReadLine() ?? string.Empty;
                        if (!string.IsNullOrWhiteSpace(path))
                        {
                            _configManager.Config.DatabasePath = path;
                            _configManager.SaveConfig();
                        }
                        else
                        {
                            ConsoleHelper.WriteWarning("Путь не может быть пустым.");
                            WaitForKeyPress();
                        }
                        break;
                    case 5:
                        exit = true;
                        break;
                    default:
                        ConsoleHelper.WriteWarning("Неверный выбор.");
                        WaitForKeyPress();
                        break;
                }
            }
            else
            {
                ConsoleHelper.WriteWarning("Неверный ввод. Пожалуйста, введите число.");
                WaitForKeyPress();
            }
        }
    }

    /// <summary>
    /// Ожидает нажатия клавиши пользователем
    /// </summary>
    private void WaitForKeyPress()
    {
        Console.WriteLine("\nНажмите любую клавишу для продолжения...");
        Console.ReadKey(true);
    }
} 