using System.Text.Json;

namespace WindowsDriverProtection.Utils;

/// <summary>
/// Class for managing application configuration
/// </summary>
public class ConfigManager
{
    private const string ConfigFileName = "config.json";
    private readonly string _configFilePath;
    private AppConfig _config;

    /// <summary>
    /// ConfigManager constructor
    /// </summary>
    public ConfigManager()
    {
        _configFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, ConfigFileName);
        LoadConfig();
    }

    /// <summary>
    /// Current application configuration
    /// </summary>
    public AppConfig Config => _config;

    /// <summary>
    /// Loads configuration from file
    /// </summary>
    private void LoadConfig()
    {
        try
        {
            if (File.Exists(_configFilePath))
            {
                string json = File.ReadAllText(_configFilePath);
                _config = JsonSerializer.Deserialize<AppConfig>(json) ?? CreateDefaultConfig();
            }
            else
            {
                _config = CreateDefaultConfig();
                SaveConfig();
            }
        }
        catch (Exception ex)
        {
            ConsoleHelper.WriteError($"Error loading configuration: {ex.Message}");
            _config = CreateDefaultConfig();
        }
    }

    /// <summary>
    /// Saves configuration to file
    /// </summary>
    public void SaveConfig()
    {
        try
        {
            string json = JsonSerializer.Serialize(_config, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_configFilePath, json);
        }
        catch (Exception ex)
        {
            ConsoleHelper.WriteError($"Error saving configuration: {ex.Message}");
        }
    }

    /// <summary>
    /// Creates default configuration
    /// </summary>
    private AppConfig CreateDefaultConfig()
    {
        return new AppConfig
        {
            DatabasePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "drivers_db.json"),
            ScanIntervalMinutes = 60,
            EnableNotifications = true,
            AutoUpdateDatabase = true,
            LastDatabaseUpdate = DateTime.MinValue,
            ExcludedDrivers = new List<string>()
        };
    }
}

/// <summary>
/// Class representing application configuration
/// </summary>
public class AppConfig
{
    /// <summary>
    /// Path to the drivers database file
    /// </summary>
    public string DatabasePath { get; set; } = string.Empty;
    
    /// <summary>
    /// Scan interval in minutes
    /// </summary>
    public int ScanIntervalMinutes { get; set; }
    
    /// <summary>
    /// Whether notifications are enabled
    /// </summary>
    public bool EnableNotifications { get; set; }
    
    /// <summary>
    /// Automatic database updates
    /// </summary>
    public bool AutoUpdateDatabase { get; set; }
    
    /// <summary>
    /// Date of last database update
    /// </summary>
    public DateTime LastDatabaseUpdate { get; set; }
    
    /// <summary>
    /// List of excluded drivers
    /// </summary>
    public List<string> ExcludedDrivers { get; set; } = new();
} 