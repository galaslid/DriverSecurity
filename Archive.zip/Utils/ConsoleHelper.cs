namespace WindowsDriverProtection.Utils;

/// <summary>
/// Helper class for console operations
/// </summary>
public static class ConsoleHelper
{
    /// <summary>
    /// Displays a message with info color
    /// </summary>
    public static void WriteInfo(string message)
    {
        var originalColor = Console.ForegroundColor;
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine(message);
        Console.ForegroundColor = originalColor;
    }
    
    /// <summary>
    /// Displays a message with success color
    /// </summary>
    public static void WriteSuccess(string message)
    {
        var originalColor = Console.ForegroundColor;
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine(message);
        Console.ForegroundColor = originalColor;
    }
    
    /// <summary>
    /// Displays a message with warning color
    /// </summary>
    public static void WriteWarning(string message)
    {
        var originalColor = Console.ForegroundColor;
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine(message);
        Console.ForegroundColor = originalColor;
    }
    
    /// <summary>
    /// Displays a message with error color
    /// </summary>
    public static void WriteError(string message)
    {
        var originalColor = Console.ForegroundColor;
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine(message);
        Console.ForegroundColor = originalColor;
    }
    
    /// <summary>
    /// Displays a header with color
    /// </summary>
    public static void WriteHeader(string header)
    {
        var originalColor = Console.ForegroundColor;
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine(new string('=', 50));
        Console.WriteLine(header);
        Console.WriteLine(new string('=', 50));
        Console.ForegroundColor = originalColor;
    }
    
    /// <summary>
    /// Displays a separator line
    /// </summary>
    public static void WriteSeparator()
    {
        Console.WriteLine(new string('-', 50));
    }
    
    /// <summary>
    /// Displays driver information with color formatting
    /// </summary>
    public static void WriteDriverInfo(Models.DriverInfo driver)
    {
        var originalColor = Console.ForegroundColor;
        
        Console.WriteLine($"Driver: {driver.Name}");
        Console.WriteLine($"Display Name: {driver.DisplayName}");
        Console.WriteLine($"Path: {driver.Path}");
        Console.WriteLine($"State: {driver.State}");
        Console.WriteLine($"Start Mode: {driver.StartMode}");
        Console.WriteLine($"SHA-256: {driver.Hash}");
        
        Console.Write("Signed: ");
        if (driver.IsSigned)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Yes");
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("No");
        }
        
        Console.ForegroundColor = originalColor;
        Console.Write("Vulnerable: ");
        if (driver.IsVulnerable)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Yes");
            
            if (!string.IsNullOrEmpty(driver.VulnerabilityInfo))
            {
                Console.ForegroundColor = originalColor;
                Console.WriteLine("\nVulnerability Information:");
                Console.WriteLine($"Category: {driver.VulnerabilityCategory}");
                Console.WriteLine($"Description: {driver.VulnerabilityInfo}");
            }
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("No");
        }
        
        Console.ForegroundColor = originalColor;
    }
} 