using System;

namespace WindowsDriverInfo.Models;

public enum DriverEventType
{
    Existing,
    Loaded,
    Unloaded,
    Modified
}

public class DriverEvent
{
    public string DriverName { get; set; } = string.Empty;
    public string DriverDisplayName { get; set; } = string.Empty;
    public string DriverPath { get; set; } = string.Empty;
    public string DriverState { get; set; } = string.Empty;
    public string DriverStartMode { get; set; } = string.Empty;
    public string DriverHash { get; set; } = string.Empty;
    public DriverEventType EventType { get; set; }
    public DateTime Timestamp { get; set; }
    public bool IsVulnerable { get; set; }
    public LolDriver? VulnerabilityInfo { get; set; }
    
    public override string ToString()
    {
        return $"[{Timestamp:yyyy-MM-dd HH:mm:ss}] {EventType} - {DriverName} ({(IsVulnerable ? "VULNERABLE" : "OK")})";
    }
    
    public string GetDetailedInfo()
    {
        var result = $"Driver: {DriverName}\n" +
                     $"Display Name: {DriverDisplayName}\n" +
                     $"Path: {DriverPath}\n" +
                     $"State: {DriverState}\n" +
                     $"Start Mode: {DriverStartMode}\n" +
                     $"SHA-256: {DriverHash}\n" +
                     $"Event Type: {EventType}\n" +
                     $"Timestamp: {Timestamp:yyyy-MM-dd HH:mm:ss}\n" +
                     $"Vulnerable: {(IsVulnerable ? "YES" : "NO")}";
        
        if (IsVulnerable && VulnerabilityInfo != null)
        {
            result += $"\n\nVulnerability Information:\n" +
                      $"Category: {VulnerabilityInfo.Category}\n";
            
            if (!string.IsNullOrEmpty(VulnerabilityInfo.Commands.Description))
            {
                result += $"Description: {VulnerabilityInfo.Commands.Description}\n";
            }
            
            if (!string.IsNullOrEmpty(VulnerabilityInfo.MitreId))
            {
                result += $"MITRE ID: {VulnerabilityInfo.MitreId}\n";
            }
        }
        
        return result;
    }
} 