using WindowsDriverInfo.Services;
using WindowsDriverInfo.Models;

namespace WindowsDriverInfo;

public class Program
{
    static async Task Main(string[] args)
    {
        if (!OperatingSystem.IsWindows())
        {
            Console.WriteLine("This program is intended only for Windows.");
            return;
        }

        var provider = new DriverInfoProvider();
        var driverBlockService = new DriverBlockService();
        var wdacService = new WdacService();
        var notificationService = new NotificationService();
        var lolDriversService = new LolDriversService();
        var driverMonitorService = new DriverMonitorService(lolDriversService);
        
        // Регистрируем обработчики событий
        driverMonitorService.RegisterEventHandler(driverEvent => {
            if (driverEvent.IsVulnerable)
            {
                notificationService.ShowVulnerableDriverNotification(driverEvent);
            }
            else if (driverEvent.EventType == DriverEventType.Loaded)
            {
                notificationService.ShowDriverLoadedNotification(driverEvent);
            }
        });
        
        bool exit = false;

        while (!exit)
        {
            Console.Clear();
            Console.WriteLine("=== Windows Driver Protection System ===");
            Console.WriteLine("1. Check Driver Signature Status");
            Console.WriteLine("2. Check Driver BYOD Status");
            Console.WriteLine("3. Check Driver Services");
            Console.WriteLine("4. Check Driver Exposed Devices");
            Console.WriteLine("5. Check WFP Status");
            Console.WriteLine("6. Check for Vulnerable Drivers");
            Console.WriteLine("7. Check Specific Driver");
            Console.WriteLine("8. Start Driver Monitoring");
            Console.WriteLine("9. Stop Driver Monitoring");
            Console.WriteLine("10. Enable Driver Blocking");
            Console.WriteLine("11. Block Specific Driver");
            Console.WriteLine("12. Quarantine Driver");
            Console.WriteLine("13. View Quarantined Drivers");
            Console.WriteLine("14. Restore Driver from Quarantine");
            Console.WriteLine("15. Check WDAC Status");
            Console.WriteLine("16. Enable WDAC");
            Console.WriteLine("17. Create Driver Block Policy");
            Console.WriteLine("18. View Notification History");
            Console.WriteLine("19. View Event Log");
            Console.WriteLine("0. Exit");

            if (int.TryParse(Console.ReadLine(), out int choice))
            {
                Console.Clear();
                try
                {
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine($"Driver signature status: {provider.CheckDriverSignatureEnforcement()}");
                            break;
                        case 2:
                            Console.WriteLine(provider.GetDriverBYODStatus());
                            break;
                        case 3:
                            Console.WriteLine(provider.CheckDriverServices());
                            break;
                        case 4:
                            Console.WriteLine(provider.CheckDriverExposedDevices());
                            break;
                        case 5:
                            Console.WriteLine(provider.CheckWFPStatus());
                            break;
                        case 6:
                            await provider.CheckDriversAgainstLolDriversDb();
                            break;
                        case 7:
                            Console.Write("Enter driver name (with .sys extension): ");
                            var driverName = Console.ReadLine();
                            if (string.IsNullOrWhiteSpace(driverName))
                            {
                                Console.WriteLine("Invalid driver name!");
                                break;
                            }
                            if (!driverName.EndsWith(".sys", StringComparison.OrdinalIgnoreCase))
                            {
                                driverName += ".sys";
                            }
                            Console.WriteLine(provider.CheckSpecificDriver(driverName));
                            break;
                        case 8:
                            driverMonitorService.StartMonitoring();
                            Console.WriteLine("Driver monitoring started. You will be notified of new or vulnerable drivers.");
                            break;
                        case 9:
                            driverMonitorService.StopMonitoring();
                            Console.WriteLine("Driver monitoring stopped.");
                            break;
                        case 10:
                            var isEnabled = driverBlockService.EnableDriverBlocking();
                            Console.WriteLine($"Driver blocking {(isEnabled ? "enabled" : "failed to enable")}.");
                            Console.WriteLine("Note: You may need to restart your computer for changes to take effect.");
                            break;
                        case 11:
                            Console.Write("Enter driver hash (SHA-256): ");
                            var driverHash = Console.ReadLine();
                            if (string.IsNullOrWhiteSpace(driverHash))
                            {
                                Console.WriteLine("Invalid driver hash!");
                                break;
                            }
                            var isBlocked = driverBlockService.BlockDriver(driverHash);
                            Console.WriteLine($"Driver {(isBlocked ? "blocked" : "failed to block")}.");
                            break;
                        case 12:
                            Console.Write("Enter driver path: ");
                            var driverPath = Console.ReadLine();
                            if (string.IsNullOrWhiteSpace(driverPath) || !File.Exists(driverPath))
                            {
                                Console.WriteLine("Invalid driver path!");
                                break;
                            }
                            var isQuarantined = driverBlockService.QuarantineDriver(driverPath);
                            Console.WriteLine($"Driver {(isQuarantined ? "quarantined" : "failed to quarantine")}.");
                            break;
                        case 13:
                            var quarantinedDrivers = driverBlockService.GetQuarantinedDrivers();
                            Console.WriteLine($"Quarantined Drivers ({quarantinedDrivers.Length}):");
                            foreach (var driver in quarantinedDrivers)
                            {
                                Console.WriteLine($"- {driver}");
                            }
                            break;
                        case 14:
                            Console.Write("Enter driver name to restore: ");
                            var driverToRestore = Console.ReadLine();
                            if (string.IsNullOrWhiteSpace(driverToRestore))
                            {
                                Console.WriteLine("Invalid driver name!");
                                break;
                            }
                            var isRestored = driverBlockService.RestoreDriverFromQuarantine(driverToRestore);
                            Console.WriteLine($"Driver {(isRestored ? "restored" : "failed to restore")}.");
                            break;
                        case 15:
                            Console.WriteLine(wdacService.GetWdacStatus());
                            break;
                        case 16:
                            var isWdacEnabled = wdacService.EnableWdac();
                            Console.WriteLine($"WDAC {(isWdacEnabled ? "enabled" : "failed to enable")}.");
                            Console.WriteLine("Note: You may need to restart your computer for changes to take effect.");
                            break;
                        case 17:
                            Console.WriteLine("Creating driver block policy...");
                            Console.WriteLine("Enter driver hashes to block (one per line, empty line to finish):");
                            var hashes = new List<string>();
                            while (true)
                            {
                                var hash = Console.ReadLine();
                                if (string.IsNullOrWhiteSpace(hash))
                                {
                                    break;
                                }
                                hashes.Add(hash);
                            }
                            
                            if (hashes.Count == 0)
                            {
                                Console.WriteLine("No hashes provided!");
                                break;
                            }
                            
                            Console.Write("Enter policy name: ");
                            var policyName = Console.ReadLine();
                            if (string.IsNullOrWhiteSpace(policyName))
                            {
                                policyName = "DriverBlockPolicy";
                            }
                            
                            var policyPath = wdacService.CreateDriverBlockPolicy(hashes, policyName);
                            Console.WriteLine($"Policy created at: {policyPath}");
                            
                            Console.Write("Do you want to deploy this policy now? (y/n): ");
                            var deploy = Console.ReadLine();
                            if (deploy?.ToLower() == "y")
                            {
                                var isDeployed = wdacService.CompileAndDeployPolicy(policyPath);
                                Console.WriteLine($"Policy {(isDeployed ? "deployed" : "failed to deploy")}.");
                            }
                            break;
                        case 18:
                            var history = notificationService.GetNotificationHistory();
                            Console.WriteLine($"Notification History ({history.Count}):");
                            foreach (var notification in history)
                            {
                                Console.WriteLine(notification);
                            }
                            break;
                        case 19:
                            Console.WriteLine("Event Log:");
                            Console.WriteLine(notificationService.ReadLogFile());
                            break;
                        case 0:
                            exit = true;
                            continue;
                        default:
                            Console.WriteLine("Invalid choice!");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
                
                Console.WriteLine("\nPress any key to continue...");
                Console.ReadKey();
            }
        }
        
        // Останавливаем мониторинг при выходе
        driverMonitorService.Dispose();
    }
}
