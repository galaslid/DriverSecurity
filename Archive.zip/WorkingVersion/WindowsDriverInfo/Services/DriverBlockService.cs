using System;
using System.Diagnostics;
using System.IO;
using System.Security.AccessControl;
using System.Security.Principal;
using Microsoft.Win32;
using WindowsDriverInfo.Models;

namespace WindowsDriverInfo.Services;

public class DriverBlockService
{
    private const string BlockListRegistryPath = @"SYSTEM\CurrentControlSet\Control\CI\DriverBlock";
    
    public bool IsDriverBlockingEnabled()
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\CI\Config");
            if (key != null)
            {
                var value = key.GetValue("VulnerableDriverBlocklistEnable");
                return value != null && ((int)value == 1);
            }
            return false;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error checking driver blocking status: {ex.Message}");
        }
    }
    
    public bool EnableDriverBlocking()
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        try
        {
            using var key = Registry.LocalMachine.CreateSubKey(@"SYSTEM\CurrentControlSet\Control\CI\Config");
            if (key != null)
            {
                key.SetValue("VulnerableDriverBlocklistEnable", 1, RegistryValueKind.DWord);
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error enabling driver blocking: {ex.Message}. Make sure you run as Administrator.");
        }
    }
    
    public bool BlockDriver(string driverHash)
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        if (string.IsNullOrEmpty(driverHash))
            throw new ArgumentException("Driver hash cannot be empty");
            
        try
        {
            using var key = Registry.LocalMachine.CreateSubKey(BlockListRegistryPath);
            if (key != null)
            {
                key.SetValue(driverHash, 0, RegistryValueKind.DWord);
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error blocking driver: {ex.Message}. Make sure you run as Administrator.");
        }
    }
    
    public bool UnblockDriver(string driverHash)
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        if (string.IsNullOrEmpty(driverHash))
            throw new ArgumentException("Driver hash cannot be empty");
            
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(BlockListRegistryPath, true);
            if (key != null && key.GetValue(driverHash) != null)
            {
                key.DeleteValue(driverHash);
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error unblocking driver: {ex.Message}. Make sure you run as Administrator.");
        }
    }
    
    public bool IsDriverBlocked(string driverHash)
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        if (string.IsNullOrEmpty(driverHash))
            throw new ArgumentException("Driver hash cannot be empty");
            
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(BlockListRegistryPath);
            if (key != null)
            {
                return key.GetValue(driverHash) != null;
            }
            return false;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error checking if driver is blocked: {ex.Message}");
        }
    }
    
    public bool QuarantineDriver(string driverPath)
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        if (string.IsNullOrEmpty(driverPath) || !File.Exists(driverPath))
            throw new ArgumentException("Invalid driver path");
            
        try
        {
            // Создаем папку для карантина, если она не существует
            var quarantinePath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "DriverQuarantine"
            );
            
            if (!Directory.Exists(quarantinePath))
            {
                Directory.CreateDirectory(quarantinePath);
            }
            
            // Получаем имя файла драйвера
            var driverName = Path.GetFileName(driverPath);
            var quarantineFilePath = Path.Combine(quarantinePath, $"{driverName}.quarantine");
            
            // Копируем драйвер в карантин
            File.Copy(driverPath, quarantineFilePath, true);
            
            // Изменяем разрешения на оригинальный файл, чтобы предотвратить его использование
            var fileInfo = new FileInfo(driverPath);
            var security = fileInfo.GetAccessControl();
            
            // Запрещаем доступ для всех пользователей
            var everyone = new SecurityIdentifier(WellKnownSidType.WorldSid, null);
            security.AddAccessRule(new FileSystemAccessRule(
                everyone,
                FileSystemRights.ReadAndExecute,
                AccessControlType.Deny
            ));
            
            fileInfo.SetAccessControl(security);
            
            return true;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error quarantining driver: {ex.Message}. Make sure you run as Administrator.");
        }
    }
    
    public bool RestoreDriverFromQuarantine(string driverName)
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        if (string.IsNullOrEmpty(driverName))
            throw new ArgumentException("Driver name cannot be empty");
            
        try
        {
            var quarantinePath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "DriverQuarantine"
            );
            
            var quarantineFilePath = Path.Combine(quarantinePath, $"{driverName}.quarantine");
            
            if (!File.Exists(quarantineFilePath))
            {
                throw new FileNotFoundException($"Driver {driverName} not found in quarantine");
            }
            
            // Определяем путь для восстановления
            var systemDriversPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.Windows),
                "System32",
                "drivers"
            );
            
            var restorePath = Path.Combine(systemDriversPath, driverName);
            
            // Восстанавливаем драйвер
            if (File.Exists(restorePath))
            {
                // Сбрасываем разрешения на файл
                var fileInfo = new FileInfo(restorePath);
                var security = fileInfo.GetAccessControl();
                
                var everyone = new SecurityIdentifier(WellKnownSidType.WorldSid, null);
                security.RemoveAccessRule(new FileSystemAccessRule(
                    everyone,
                    FileSystemRights.ReadAndExecute,
                    AccessControlType.Deny
                ));
                
                fileInfo.SetAccessControl(security);
            }
            else
            {
                // Копируем файл обратно, если он был удален
                File.Copy(quarantineFilePath, restorePath, true);
            }
            
            return true;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error restoring driver from quarantine: {ex.Message}. Make sure you run as Administrator.");
        }
    }
    
    public string[] GetQuarantinedDrivers()
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        try
        {
            var quarantinePath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "DriverQuarantine"
            );
            
            if (!Directory.Exists(quarantinePath))
            {
                return Array.Empty<string>();
            }
            
            var quarantinedFiles = Directory.GetFiles(quarantinePath, "*.quarantine");
            var result = new string[quarantinedFiles.Length];
            
            for (int i = 0; i < quarantinedFiles.Length; i++)
            {
                result[i] = Path.GetFileNameWithoutExtension(quarantinedFiles[i]);
            }
            
            return result;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error getting quarantined drivers: {ex.Message}");
        }
    }
} 