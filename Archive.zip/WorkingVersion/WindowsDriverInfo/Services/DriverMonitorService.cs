using System;
using System.Management;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
using WindowsDriverInfo.Models;

namespace WindowsDriverInfo.Services;

public class DriverMonitorService : IDisposable
{
    private ManagementEventWatcher? _watcher;
    private CancellationTokenSource? _cancellationTokenSource;
    private readonly LolDriversService _lolDriversService;
    private readonly List<Action<DriverEvent>> _eventHandlers = new();
    private bool _isDisposed;

    public DriverMonitorService(LolDriversService lolDriversService)
    {
        _lolDriversService = lolDriversService;
    }

    public void RegisterEventHandler(Action<DriverEvent> handler)
    {
        _eventHandlers.Add(handler);
    }

    public void StartMonitoring()
    {
        if (_watcher != null)
        {
            return;
        }

        try
        {
            // Создаем WMI запрос для отслеживания событий загрузки драйверов
            var query = new WqlEventQuery(
                "__InstanceCreationEvent",
                TimeSpan.FromSeconds(1),
                "TargetInstance ISA 'Win32_SystemDriver'"
            );

            _watcher = new ManagementEventWatcher(query);
            _watcher.EventArrived += OnDriverEvent;
            _watcher.Start();

            _cancellationTokenSource = new CancellationTokenSource();
            Task.Run(() => CheckExistingDriversAsync(_cancellationTokenSource.Token));

            Console.WriteLine("Driver monitoring started.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error starting driver monitoring: {ex.Message}");
        }
    }

    public void StopMonitoring()
    {
        if (_watcher != null)
        {
            _watcher.EventArrived -= OnDriverEvent;
            _watcher.Stop();
            _watcher.Dispose();
            _watcher = null;
        }

        _cancellationTokenSource?.Cancel();
        Console.WriteLine("Driver monitoring stopped.");
    }

    private async Task CheckExistingDriversAsync(CancellationToken cancellationToken)
    {
        try
        {
            var vulnerableDrivers = await _lolDriversService.GetVulnerableDriversAsync();
            var systemDrivers = _lolDriversService.GetSystemDrivers();

            foreach (var driverPath in systemDrivers)
            {
                if (cancellationToken.IsCancellationRequested)
                {
                    return;
                }

                try
                {
                    var driverName = Path.GetFileName(driverPath);
                    var driverEvent = new DriverEvent
                    {
                        DriverName = driverName,
                        DriverPath = driverPath,
                        EventType = DriverEventType.Existing,
                        Timestamp = DateTime.Now
                    };

                    // Проверяем, является ли драйвер уязвимым
                    await CheckDriverVulnerabilityAsync(driverEvent, vulnerableDrivers);

                    // Уведомляем обработчики событий
                    NotifyEventHandlers(driverEvent);
                }
                catch (Exception) { }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error checking existing drivers: {ex.Message}");
        }
    }

    private void OnDriverEvent(object sender, EventArrivedEventArgs e)
    {
        try
        {
            var instance = (ManagementBaseObject)e.NewEvent["TargetInstance"];
            var driverName = instance["Name"]?.ToString() ?? "Unknown";
            var displayName = instance["DisplayName"]?.ToString() ?? "Unknown";
            var state = instance["State"]?.ToString() ?? "Unknown";
            var startMode = instance["StartMode"]?.ToString() ?? "Unknown";
            var pathName = instance["PathName"]?.ToString() ?? "Unknown";

            var driverEvent = new DriverEvent
            {
                DriverName = driverName,
                DriverDisplayName = displayName,
                DriverPath = pathName,
                DriverState = state,
                DriverStartMode = startMode,
                EventType = DriverEventType.Loaded,
                Timestamp = DateTime.Now
            };

            Task.Run(async () =>
            {
                var vulnerableDrivers = await _lolDriversService.GetVulnerableDriversAsync();
                await CheckDriverVulnerabilityAsync(driverEvent, vulnerableDrivers);
                NotifyEventHandlers(driverEvent);
            });
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error processing driver event: {ex.Message}");
        }
    }

    private async Task CheckDriverVulnerabilityAsync(DriverEvent driverEvent, List<LolDriver> vulnerableDrivers)
    {
        if (string.IsNullOrEmpty(driverEvent.DriverPath) || !File.Exists(driverEvent.DriverPath))
        {
            return;
        }

        try
        {
            using var sha256 = System.Security.Cryptography.SHA256.Create();
            using var stream = File.OpenRead(driverEvent.DriverPath);
            var hash = BitConverter.ToString(sha256.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
            driverEvent.DriverHash = hash;

            foreach (var vulnDriver in vulnerableDrivers)
            {
                if ((vulnDriver.Tags.Any() && driverEvent.DriverName.ToLower() == vulnDriver.Tags[0].ToLower()) ||
                    vulnDriver.GetKnownVulnerableSamples().Contains(hash, StringComparer.OrdinalIgnoreCase))
                {
                    driverEvent.IsVulnerable = true;
                    driverEvent.VulnerabilityInfo = vulnDriver;
                    break;
                }
            }
        }
        catch (Exception) { }
    }

    private void NotifyEventHandlers(DriverEvent driverEvent)
    {
        foreach (var handler in _eventHandlers)
        {
            try
            {
                handler(driverEvent);
            }
            catch (Exception) { }
        }
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (_isDisposed)
        {
            return;
        }

        if (disposing)
        {
            StopMonitoring();
            _cancellationTokenSource?.Dispose();
        }

        _isDisposed = true;
    }
} 