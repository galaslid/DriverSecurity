using System;
using System.IO;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Collections.Generic;
using WindowsDriverInfo.Models;

namespace WindowsDriverInfo.Services;

public class NotificationService
{
    private readonly List<DriverEvent> _notificationHistory = new();
    private readonly string _logFilePath;
    
    public NotificationService()
    {
        var appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        var logDirectory = Path.Combine(appDataPath, "WindowsDriverInfo");
        
        if (!Directory.Exists(logDirectory))
        {
            Directory.CreateDirectory(logDirectory);
        }
        
        _logFilePath = Path.Combine(logDirectory, "driver_events.log");
    }
    
    public void ShowVulnerableDriverNotification(DriverEvent driverEvent)
    {
        if (driverEvent == null)
            throw new ArgumentNullException(nameof(driverEvent));
            
        _notificationHistory.Add(driverEvent);
        LogDriverEvent(driverEvent);
        
        if (OperatingSystem.IsWindows())
        {
            try
            {
                // Показываем уведомление через PowerShell
                var title = "Обнаружен уязвимый драйвер!";
                var message = $"Драйвер: {driverEvent.DriverName}\nПуть: {driverEvent.DriverPath}";
                
                var psScript = $@"
                [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
                [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null

                $APP_ID = 'WindowsDriverInfo'

                $template = @""
                <toast>
                    <visual>
                        <binding template=""ToastText02"">
                            <text id=""1"">{title}</text>
                            <text id=""2"">{message}</text>
                        </binding>
                    </visual>
                    <actions>
                        <action activationType=""system"" arguments=""dismiss"" content=""Закрыть""/>
                    </actions>
                </toast>
                ""@

                $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
                $xml.LoadXml($template)
                $toast = [Windows.UI.Notifications.ToastNotification]::new($xml)
                [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($APP_ID).Show($toast)
                ";
                
                var startInfo = new ProcessStartInfo
                {
                    FileName = "powershell",
                    Arguments = $"-Command \"{psScript}\"",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                
                using var process = Process.Start(startInfo);
                process?.WaitForExit();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error showing notification: {ex.Message}");
            }
        }
        else
        {
            // Для не-Windows систем просто выводим в консоль
            Console.WriteLine("\n=== УВЕДОМЛЕНИЕ О УЯЗВИМОМ ДРАЙВЕРЕ ===");
            Console.WriteLine(driverEvent.GetDetailedInfo());
            Console.WriteLine("=====================================\n");
        }
    }
    
    public void ShowDriverLoadedNotification(DriverEvent driverEvent)
    {
        if (driverEvent == null)
            throw new ArgumentNullException(nameof(driverEvent));
            
        _notificationHistory.Add(driverEvent);
        LogDriverEvent(driverEvent);
        
        if (OperatingSystem.IsWindows())
        {
            try
            {
                // Показываем уведомление через PowerShell
                var title = "Загружен новый драйвер";
                var message = $"Драйвер: {driverEvent.DriverName}\nПуть: {driverEvent.DriverPath}";
                
                var psScript = $@"
                [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
                [Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null

                $APP_ID = 'WindowsDriverInfo'

                $template = @""
                <toast>
                    <visual>
                        <binding template=""ToastText02"">
                            <text id=""1"">{title}</text>
                            <text id=""2"">{message}</text>
                        </binding>
                    </visual>
                    <actions>
                        <action activationType=""system"" arguments=""dismiss"" content=""Закрыть""/>
                    </actions>
                </toast>
                ""@

                $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
                $xml.LoadXml($template)
                $toast = [Windows.UI.Notifications.ToastNotification]::new($xml)
                [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($APP_ID).Show($toast)
                ";
                
                var startInfo = new ProcessStartInfo
                {
                    FileName = "powershell",
                    Arguments = $"-Command \"{psScript}\"",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                
                using var process = Process.Start(startInfo);
                process?.WaitForExit();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error showing notification: {ex.Message}");
            }
        }
        else
        {
            // Для не-Windows систем просто выводим в консоль
            Console.WriteLine("\n=== УВЕДОМЛЕНИЕ О ЗАГРУЗКЕ ДРАЙВЕРА ===");
            Console.WriteLine(driverEvent.GetDetailedInfo());
            Console.WriteLine("=====================================\n");
        }
    }
    
    public List<DriverEvent> GetNotificationHistory()
    {
        return new List<DriverEvent>(_notificationHistory);
    }
    
    private void LogDriverEvent(DriverEvent driverEvent)
    {
        try
        {
            using var writer = new StreamWriter(_logFilePath, true);
            writer.WriteLine($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {driverEvent.EventType} - {driverEvent.DriverName}");
            writer.WriteLine($"Path: {driverEvent.DriverPath}");
            writer.WriteLine($"Hash: {driverEvent.DriverHash}");
            writer.WriteLine($"Vulnerable: {driverEvent.IsVulnerable}");
            
            if (driverEvent.IsVulnerable && driverEvent.VulnerabilityInfo != null)
            {
                writer.WriteLine($"Vulnerability Category: {driverEvent.VulnerabilityInfo.Category}");
                
                if (!string.IsNullOrEmpty(driverEvent.VulnerabilityInfo.Commands.Description))
                {
                    writer.WriteLine($"Description: {driverEvent.VulnerabilityInfo.Commands.Description}");
                }
            }
            
            writer.WriteLine(new string('-', 50));
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error logging driver event: {ex.Message}");
        }
    }
    
    public string GetLogFilePath()
    {
        return _logFilePath;
    }
    
    public string ReadLogFile()
    {
        try
        {
            if (File.Exists(_logFilePath))
            {
                return File.ReadAllText(_logFilePath);
            }
            
            return "Log file is empty.";
        }
        catch (Exception ex)
        {
            return $"Error reading log file: {ex.Message}";
        }
    }
    
    public void ClearLogFile()
    {
        try
        {
            if (File.Exists(_logFilePath))
            {
                File.WriteAllText(_logFilePath, string.Empty);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error clearing log file: {ex.Message}");
        }
    }
} 