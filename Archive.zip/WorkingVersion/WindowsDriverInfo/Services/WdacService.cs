using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using Microsoft.Win32;

namespace WindowsDriverInfo.Services;

public class WdacService
{
    private const string WdacPolicyPath = @"C:\Windows\System32\CodeIntegrity\CiPolicies\Active";
    
    public bool IsWdacEnabled()
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity");
            if (key != null)
            {
                var value = key.GetValue("Enabled");
                return value != null && (int)value == 1;
            }
            return false;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error checking WDAC status: {ex.Message}");
        }
    }
    
    public string GetWdacStatus()
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        try
        {
            var result = new StringBuilder();
            
            // Проверяем, включен ли WDAC
            result.AppendLine($"WDAC Enabled: {IsWdacEnabled()}");
            
            // Проверяем, включен ли режим аудита
            using (var key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\CI\Policy"))
            {
                if (key != null)
                {
                    var auditMode = key.GetValue("AuditMode");
                    result.AppendLine($"Audit Mode: {(auditMode != null && (int)auditMode == 1 ? "Enabled" : "Disabled")}");
                }
            }
            
            // Проверяем активные политики
            if (Directory.Exists(WdacPolicyPath))
            {
                var policies = Directory.GetFiles(WdacPolicyPath, "*.cip");
                result.AppendLine($"\nActive Policies: {policies.Length}");
                
                foreach (var policy in policies)
                {
                    result.AppendLine($"- {Path.GetFileName(policy)}");
                }
            }
            else
            {
                result.AppendLine("\nNo active policies found.");
            }
            
            return result.ToString();
        }
        catch (Exception ex)
        {
            return $"Error getting WDAC status: {ex.Message}";
        }
    }
    
    public string CreateDriverBlockPolicy(IEnumerable<string> driverHashes, string policyName = "DriverBlockPolicy")
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        try
        {
            // Создаем XML документ политики
            var doc = new XDocument(
                new XDeclaration("1.0", "utf-8", null),
                new XElement("SiPolicy",
                    new XAttribute("xmlns", "urn:schemas-microsoft-com:sipolicy"),
                    new XElement("VersionEx", "10.0.0.0"),
                    new XElement("PolicyID", Guid.NewGuid().ToString()),
                    new XElement("PolicyTypeName", "Driver Block Policy"),
                    new XElement("PlatformID", "{2E07F7E4-194C-4D20-B7C9-6F44A6C5A234}"),
                    new XElement("Rules"),
                    new XElement("FileRules"),
                    new XElement("Signers"),
                    new XElement("SigningScenarios",
                        new XElement("SigningScenario",
                            new XAttribute("Value", "131"),
                            new XAttribute("ID", "12"),
                            new XElement("ProductSigners"),
                            new XElement("FileRulesRef")
                        )
                    ),
                    new XElement("UpdatePolicySigners"),
                    new XElement("CiSigners"),
                    new XElement("HvciOptions", "0"),
                    new XElement("Settings",
                        new XElement("Setting",
                            new XAttribute("Provider", "PolicyInfo"),
                            new XAttribute("Key", "Information"),
                            new XAttribute("ValueName", "Name"),
                            new XElement("Value", policyName)
                        )
                    ),
                    new XElement("EKUs"),
                    new XElement("FileAttribRules"),
                    new XElement("Signers"),
                    new XElement("SigningScenarios"),
                    new XElement("UpdatePolicySigners"),
                    new XElement("CiSigners")
                )
            );
            
            // Добавляем хеши драйверов в политику
            var fileRulesElement = doc.Descendants("FileRules").First();
            var fileRulesRefElement = doc.Descendants("FileRulesRef").First();
            
            int ruleIndex = 0;
            foreach (var hash in driverHashes)
            {
                var ruleId = $"ID_FILEATTRIB_RULE_{ruleIndex}";
                
                fileRulesElement.Add(
                    new XElement("FileAttrib",
                        new XAttribute("ID", ruleId),
                        new XAttribute("FriendlyName", $"Block Driver {ruleIndex}"),
                        new XAttribute("Hash", hash),
                        new XAttribute("FileName", "*"),
                        new XAttribute("MinimumFileVersion", "0.0.0.0"),
                        new XAttribute("Flags", "0")
                    )
                );
                
                fileRulesRefElement.Add(
                    new XElement("FileRuleRef",
                        new XAttribute("RuleID", ruleId),
                        new XAttribute("Effect", "Deny")
                    )
                );
                
                ruleIndex++;
            }
            
            // Сохраняем политику во временный файл
            var tempPath = Path.Combine(Path.GetTempPath(), $"{policyName}.xml");
            doc.Save(tempPath);
            
            return tempPath;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error creating driver block policy: {ex.Message}");
        }
    }
    
    public bool CompileAndDeployPolicy(string policyXmlPath)
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        if (string.IsNullOrEmpty(policyXmlPath) || !File.Exists(policyXmlPath))
            throw new ArgumentException("Invalid policy XML path");
            
        try
        {
            // Компилируем политику
            var outputPath = Path.ChangeExtension(policyXmlPath, ".cip");
            
            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "ConvertFrom-CIPolicy",
                    Arguments = $"-XmlFilePath \"{policyXmlPath}\" -BinaryFilePath \"{outputPath}\"",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                }
            };
            
            process.Start();
            process.WaitForExit();
            
            if (process.ExitCode != 0 || !File.Exists(outputPath))
            {
                throw new Exception("Failed to compile policy");
            }
            
            // Копируем скомпилированную политику в системную папку
            var destPath = Path.Combine(WdacPolicyPath, Path.GetFileName(outputPath));
            File.Copy(outputPath, destPath, true);
            
            return true;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error compiling and deploying policy: {ex.Message}. Make sure you run as Administrator.");
        }
    }
    
    public bool EnableWdac()
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        try
        {
            using var key = Registry.LocalMachine.CreateSubKey(@"SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity");
            if (key != null)
            {
                key.SetValue("Enabled", 1, RegistryValueKind.DWord);
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error enabling WDAC: {ex.Message}. Make sure you run as Administrator.");
        }
    }
    
    public bool EnableAuditMode()
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        try
        {
            using var key = Registry.LocalMachine.CreateSubKey(@"SYSTEM\CurrentControlSet\Control\CI\Policy");
            if (key != null)
            {
                key.SetValue("AuditMode", 1, RegistryValueKind.DWord);
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error enabling audit mode: {ex.Message}. Make sure you run as Administrator.");
        }
    }
    
    public bool DisableAuditMode()
    {
        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("This function is only available on Windows");
            
        try
        {
            using var key = Registry.LocalMachine.CreateSubKey(@"SYSTEM\CurrentControlSet\Control\CI\Policy");
            if (key != null)
            {
                key.SetValue("AuditMode", 0, RegistryValueKind.DWord);
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error disabling audit mode: {ex.Message}. Make sure you run as Administrator.");
        }
    }
} 